import { cookies } from "next/headers";
import { randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users, type AvatarData } from "@/db/schema";

export const SESSION_COOKIE = "rbx_session";

export function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string) {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const test = scryptSync(password, salt, 64);
  const orig = Buffer.from(hash, "hex");
  return orig.length === test.length && timingSafeEqual(orig, test);
}

export function defaultAvatar(gender: string): AvatarData {
  const female = gender === "female";
  return {
    head: "#f5cd30",
    torso: female ? "#e8a0bf" : "#0d69ac",
    leftArm: "#f5cd30",
    rightArm: "#f5cd30",
    leftLeg: female ? "#e8a0bf" : "#a3a2a5",
    rightLeg: female ? "#e8a0bf" : "#a3a2a5",
    shirt: female ? "#ffffff" : "#1b7f3a",
    pants: female ? "#7b3fa0" : "#1c2b4a",
    hat: "none",
    face: "smile",
  };
}

export async function createSession(userId: number) {
  const id = randomBytes(32).toString("hex");
  await db.insert(sessions).values({ id, userId });
  const store = await cookies();
  store.set(SESSION_COOKIE, id, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 30,
  });
  return id;
}

export async function destroySession() {
  const store = await cookies();
  const id = store.get(SESSION_COOKIE)?.value;
  if (id) {
    await db.delete(sessions).where(eq(sessions.id, id));
  }
  store.delete(SESSION_COOKIE);
}

export type SessionUser = typeof users.$inferSelect;

export async function getCurrentUser(): Promise<SessionUser | null> {
  const store = await cookies();
  const id = store.get(SESSION_COOKIE)?.value;
  if (!id) return null;
  const rows = await db
    .select({ user: users })
    .from(sessions)
    .innerJoin(users, eq(sessions.userId, users.id))
    .where(eq(sessions.id, id))
    .limit(1);
  return rows[0]?.user ?? null;
}

export function publicUser(u: SessionUser) {
  return {
    id: u.id,
    username: u.username,
    gender: u.gender,
    avatar: u.avatar,
    description: u.description,
    presence: presenceOf(u),
    currentPlaceId: u.currentPlaceId,
    createdAt: u.createdAt,
  };
}

export function presenceOf(u: { presence: string; lastSeen: Date }) {
  const age = Date.now() - new Date(u.lastSeen).getTime();
  if (age > 90_000) return "offline";
  return u.presence === "ingame" ? "ingame" : "online";
}

export type PublicUser = ReturnType<typeof publicUser>;
