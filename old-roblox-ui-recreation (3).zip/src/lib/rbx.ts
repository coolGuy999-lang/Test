import type { WorldData, WorldPart } from "@/db/schema";

/* ------------------------------------------------------------------ */
/* Shared intermediate instance tree                                   */
/* ------------------------------------------------------------------ */

type Inst = {
  cls: string;
  props: Record<string, unknown>;
  children: Inst[];
  parent: Inst | null;
};

const BRICK: Record<number, string> = {
  1: "f2f3f3", 2: "a1a5a2", 3: "f9e999", 5: "d7c59a", 6: "c2dab8", 9: "e8bac8", 11: "80bbdb", 12: "cb8442",
  18: "cc8e69", 21: "c4281c", 22: "c470a0", 23: "0d69ac", 24: "f5cd30", 25: "624732", 26: "1b2a35", 27: "6d6e6c",
  28: "287f47", 29: "a1c48c", 36: "f3cf9b", 37: "4b974b", 38: "a05f35", 39: "c1cade", 40: "eceded", 41: "cd544b",
  42: "c1dff0", 43: "7bb6e8", 44: "f7f18d", 45: "b4d2e4", 47: "d9856c", 48: "84b68d", 49: "f8f184", 50: "ece8de",
  100: "eec4b6", 101: "da867a", 102: "6e99ca", 103: "c7c1b7", 104: "6b327c", 105: "e29b40", 106: "da8541",
  107: "008f9c", 108: "685c43", 110: "435493", 111: "bfb7b1", 112: "6874ac", 113: "e5adc8", 115: "c7d23c",
  116: "55a5af", 118: "b7d7d5", 119: "a4bd47", 120: "d9e4a7", 121: "e7ac58", 123: "d36f4c", 124: "923978",
  125: "eab892", 126: "a5a5cb", 127: "dcbc81", 128: "ae7a59", 131: "9ca3a8", 133: "d5733d", 134: "d8dd56",
  135: "74869d", 136: "877c90", 137: "e09864", 138: "958a73", 140: "203a56", 141: "27462d", 143: "cfe2f7",
  145: "7988a1", 146: "958ea3", 147: "938767", 148: "575857", 149: "161d32", 150: "ababab", 151: "789082",
  153: "957977", 154: "7b2e2f", 157: "fff67b", 158: "e1a4c2", 168: "756c62", 176: "97695b", 178: "b48455",
  179: "898788", 180: "d7a94b", 190: "f9d62e", 191: "e8ab2d", 192: "694028", 193: "cf6024", 194: "a3a2a5",
  195: "4667a4", 196: "23478b", 198: "8e4285", 199: "635f62", 200: "828a5d", 208: "e5e4df", 209: "b08e44",
  210: "709578", 211: "79b5b5", 212: "9fc3e9", 213: "6c81b7", 216: "8f4c2a", 217: "7c5c46", 218: "96709f",
  219: "6b629b", 220: "a7a9ce", 221: "cd6298", 222: "e4adc8", 223: "dc9095", 224: "f0d5a0", 225: "ebb87f",
  226: "fdea8d", 232: "7dbbdd", 268: "342b75", 301: "508659", 302: "5b5d69", 303: "0000ff", 304: "2c651d",
  305: "527cae", 306: "335882", 307: "1010bf", 308: "3d1585", 309: "348e40", 310: "5b9a4c", 311: "9fa2a2",
  312: "59173f", 313: "1f3a1a", 314: "9fadc0", 315: "0989cf", 316: "7b007b", 317: "7c9c6b", 318: "8ab687",
  319: "b9c4b1", 320: "cacbd1", 321: "a75e9b", 322: "7b2f7b", 323: "94be81", 324: "a8bd99", 325: "dfdfde",
  327: "990000", 328: "b1e5a6", 329: "98c2db", 330: "ff98dc", 331: "ff5959", 332: "750000", 333: "ef8f00",
  334: "f8d96d", 335: "e6e6e6", 336: "c7d4e4", 337: "ff6666", 338: "be6862", 339: "562b2b", 340: "f1e7c7",
  341: "fef3bb", 342: "e0b2d0", 343: "d490bd", 344: "965555", 345: "8f4c2a", 346: "d3b98f", 347: "e2dcbc",
  348: "edf0f4", 349: "e9dada", 350: "882e2e", 351: "bc9b5d", 352: "c7ac78", 353: "cabfa3", 354: "bbb3b2",
  355: "6c584b", 356: "a0844f", 357: "878c9c", 358: "abaead", 359: "af9d81", 360: "966a4f", 361: "564236",
  362: "7e683f", 363: "69645f", 364: "5a4c42", 365: "6a3909", 1001: "f8f8f8", 1002: "cdcdcd", 1003: "111111",
  1004: "ff0000", 1005: "ffaf00", 1006: "b480ff", 1007: "a34b4b", 1008: "c1be42", 1009: "ffff00", 1010: "0000ff",
  1011: "002060", 1012: "2154b9", 1013: "04afec", 1014: "aa5500", 1015: "aa00aa", 1016: "ff66cc", 1017: "ffaf00",
  1018: "12eed4", 1019: "00ffff", 1020: "00ff00", 1021: "3a7d15", 1022: "7f8e64", 1023: "8c5b9f", 1024: "afddff",
  1025: "ffc9c9", 1026: "b1a7ff", 1027: "9ff3e9", 1028: "ccffcc", 1029: "ffffcc", 1030: "ffcc99", 1031: "6225d1",
  1032: "ff00bf",
};

const MATERIALS: Record<number, string> = {
  256: "Plastic", 272: "SmoothPlastic", 288: "Neon", 512: "Wood", 528: "WoodPlanks", 784: "Marble", 788: "Basalt",
  800: "Slate", 804: "CrackedLava", 816: "Concrete", 820: "Limestone", 832: "Granite", 836: "Pavement", 848: "Brick",
  864: "Pebble", 880: "Cobblestone", 896: "Rock", 912: "Sandstone", 1040: "CorrodedMetal", 1056: "DiamondPlate",
  1072: "Foil", 1088: "Metal", 1280: "Grass", 1284: "LeafyGrass", 1296: "Sand", 1312: "Fabric", 1328: "Snow",
  1344: "Mud", 1360: "Ground", 1376: "Asphalt", 1392: "Salt", 1536: "Ice", 1552: "Glacier", 1568: "Glass",
  1584: "ForceField", 1600: "Air", 1616: "Water", 1632: "Cardboard", 1648: "Carpet", 1664: "CeramicTiles",
  1680: "ClayRoofTiles", 1696: "RoofShingles", 1712: "Leather", 1728: "Plaster", 1744: "Rubber",
};

const PART_CLASSES = new Set([
  "Part", "WedgePart", "CornerWedgePart", "SpawnLocation", "Seat", "VehicleSeat", "TrussPart", "MeshPart",
  "UnionOperation", "NegateOperation", "IntersectOperation", "FlagStand", "SkateboardPlatform", "Platform",
]);
const SCRIPT_CLASSES = new Set(["Script", "LocalScript", "ModuleScript"]);
const PARTICLE_CLASSES = new Set(["ParticleEmitter", "Fire", "Smoke", "Sparkles"]);
const IMAGE_CLASSES = new Set(["Decal", "Texture", "ImageLabel", "ImageButton", "Sky", "ShirtGraphic", "Shirt", "Pants"]);

/* ------------------------------------------------------------------ */
/* Minimal XML parser                                                  */
/* ------------------------------------------------------------------ */

type XNode = { tag: string; attrs: Record<string, string>; children: XNode[]; text: string };

function parseXml(src: string): XNode {
  const root: XNode = { tag: "#root", attrs: {}, children: [], text: "" };
  const stack: XNode[] = [root];
  let i = 0;
  const n = src.length;
  const decode = (s: string) =>
    s.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, "&");
  while (i < n) {
    const lt = src.indexOf("<", i);
    if (lt === -1) break;
    if (lt > i) stack[stack.length - 1].text += decode(src.slice(i, lt));
    if (src.startsWith("<!--", lt)) {
      const end = src.indexOf("-->", lt);
      i = end === -1 ? n : end + 3;
      continue;
    }
    if (src.startsWith("<![CDATA[", lt)) {
      const end = src.indexOf("]]>", lt);
      stack[stack.length - 1].text += src.slice(lt + 9, end === -1 ? n : end);
      i = end === -1 ? n : end + 3;
      continue;
    }
    if (src.startsWith("<?", lt) || src.startsWith("<!", lt)) {
      const end = src.indexOf(">", lt);
      i = end === -1 ? n : end + 1;
      continue;
    }
    const gt = src.indexOf(">", lt);
    if (gt === -1) break;
    const raw = src.slice(lt + 1, gt);
    i = gt + 1;
    if (raw.startsWith("/")) {
      if (stack.length > 1) stack.pop();
      continue;
    }
    const selfClose = raw.endsWith("/");
    const body = selfClose ? raw.slice(0, -1) : raw;
    const m = body.match(/^([^\s]+)\s*([\s\S]*)$/);
    if (!m) continue;
    const node: XNode = { tag: m[1], attrs: {}, children: [], text: "" };
    const attrRe = /([^\s=]+)\s*=\s*("([^"]*)"|'([^']*)')/g;
    let am: RegExpExecArray | null;
    while ((am = attrRe.exec(m[2]))) node.attrs[am[1]] = decode(am[3] ?? am[4] ?? "");
    stack[stack.length - 1].children.push(node);
    if (!selfClose) stack.push(node);
  }
  return root;
}

function childByTag(node: XNode, tag: string) {
  return node.children.find((c) => c.tag === tag);
}
function numOf(node: XNode | undefined, tag: string, def = 0) {
  const c = node ? childByTag(node, tag) : undefined;
  const v = c ? parseFloat(c.text.trim()) : NaN;
  return Number.isFinite(v) ? v : def;
}

function xmlItemToInst(item: XNode, parent: Inst | null): Inst {
  const inst: Inst = { cls: item.attrs.class ?? "Instance", props: {}, children: [], parent };
  const propsNode = childByTag(item, "Properties");
  if (propsNode) {
    for (const p of propsNode.children) {
      const name = p.attrs.name;
      if (!name) continue;
      const t = p.text.trim();
      switch (p.tag) {
        case "string":
        case "ProtectedString":
        case "BinaryString":
        case "Content":
          inst.props[name] = p.tag === "Content" ? (childByTag(p, "url")?.text ?? t) : p.text;
          break;
        case "bool":
          inst.props[name] = t === "true";
          break;
        case "int":
        case "int64":
        case "float":
        case "double":
        case "token":
          inst.props[name] = parseFloat(t);
          break;
        case "Color3uint8":
          inst.props[name] = argbToHex(parseInt(t, 10));
          break;
        case "Color3": {
          const r = numOf(p, "R"), g = numOf(p, "G"), b = numOf(p, "B");
          inst.props[name] = rgbToHex(r, g, b);
          break;
        }
        case "Vector3":
          inst.props[name] = [numOf(p, "X"), numOf(p, "Y"), numOf(p, "Z")];
          break;
        case "CoordinateFrame":
        case "CFrame":
          inst.props[name] = [
            numOf(p, "X"), numOf(p, "Y"), numOf(p, "Z"),
            numOf(p, "R00", 1), numOf(p, "R01"), numOf(p, "R02"),
            numOf(p, "R10"), numOf(p, "R11", 1), numOf(p, "R12"),
            numOf(p, "R20"), numOf(p, "R21"), numOf(p, "R22", 1),
          ];
          break;
        case "NumberRange": {
          const parts = t.split(/\s+/).map(parseFloat);
          inst.props[name] = [parts[0] ?? 0, parts[1] ?? parts[0] ?? 0];
          break;
        }
        case "ColorSequence": {
          const parts = t.split(/\s+/).map(parseFloat);
          if (parts.length >= 4) inst.props[name] = rgbToHex(parts[1], parts[2], parts[3]);
          break;
        }
        default:
          break;
      }
    }
  }
  for (const c of item.children) {
    if (c.tag === "Item") inst.children.push(xmlItemToInst(c, inst));
  }
  return inst;
}

export function parseRbxlx(text: string): Inst[] {
  const root = parseXml(text);
  const roblox = childByTag(root, "roblox") ?? root;
  return roblox.children.filter((c) => c.tag === "Item").map((c) => xmlItemToInst(c, null));
}

/* ------------------------------------------------------------------ */
/* Binary rbxl parser                                                  */
/* ------------------------------------------------------------------ */

function lz4Decode(src: Uint8Array, outLen: number): Uint8Array {
  const out = new Uint8Array(outLen);
  let si = 0;
  let di = 0;
  while (si < src.length && di < outLen) {
    const token = src[si++];
    let lit = token >> 4;
    if (lit === 15) {
      let b: number;
      do {
        b = src[si++];
        lit += b;
      } while (b === 255);
    }
    out.set(src.subarray(si, si + lit), di);
    si += lit;
    di += lit;
    if (si >= src.length) break;
    const offset = src[si] | (src[si + 1] << 8);
    si += 2;
    let mlen = token & 15;
    if (mlen === 15) {
      let b: number;
      do {
        b = src[si++];
        mlen += b;
      } while (b === 255);
    }
    mlen += 4;
    let ref = di - offset;
    for (let k = 0; k < mlen && di < outLen; k++) out[di++] = out[ref++];
  }
  return out;
}

class Reader {
  pos = 0;
  dv: DataView;
  constructor(public buf: Uint8Array) {
    this.dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  }
  get eof() {
    return this.pos >= this.buf.length;
  }
  u8() {
    return this.buf[this.pos++];
  }
  u16() {
    const v = this.dv.getUint16(this.pos, true);
    this.pos += 2;
    return v;
  }
  u32() {
    const v = this.dv.getUint32(this.pos, true);
    this.pos += 4;
    return v;
  }
  i32() {
    const v = this.dv.getInt32(this.pos, true);
    this.pos += 4;
    return v;
  }
  f32() {
    const v = this.dv.getFloat32(this.pos, true);
    this.pos += 4;
    return v;
  }
  bytes(n: number) {
    const v = this.buf.subarray(this.pos, this.pos + n);
    this.pos += n;
    return v;
  }
  str() {
    const len = this.u32();
    const b = this.bytes(len);
    return new TextDecoder().decode(b);
  }
  interleavedU32(n: number) {
    const b = this.bytes(n * 4);
    const out = new Array<number>(n);
    for (let i = 0; i < n; i++) {
      out[i] = ((b[i] << 24) | (b[n + i] << 16) | (b[2 * n + i] << 8) | b[3 * n + i]) >>> 0;
    }
    return out;
  }
  interleavedI32(n: number) {
    return this.interleavedU32(n).map((u) => ((u >>> 1) ^ -(u & 1)) | 0);
  }
  interleavedF32(n: number) {
    const raw = this.interleavedU32(n);
    const tmp = new DataView(new ArrayBuffer(4));
    return raw.map((u) => {
      const rot = ((u >>> 1) | (u << 31)) >>> 0;
      tmp.setUint32(0, rot);
      return tmp.getFloat32(0);
    });
  }
  referents(n: number) {
    const arr = this.interleavedI32(n);
    let acc = 0;
    for (let i = 0; i < n; i++) {
      acc += arr[i];
      arr[i] = acc;
    }
    return arr;
  }
}

const NORMALS: number[][] = [
  [1, 0, 0], [0, 1, 0], [0, 0, 1], [-1, 0, 0], [0, -1, 0], [0, 0, -1],
];
function basicRotation(id: number): number[] {
  const n = id - 1;
  const x = NORMALS[Math.floor(n / 6)] ?? NORMALS[0];
  const y = NORMALS[n % 6] ?? NORMALS[1];
  const z = [x[1] * y[2] - x[2] * y[1], x[2] * y[0] - x[0] * y[2], x[0] * y[1] - x[1] * y[0]];
  return [x[0], y[0], z[0], x[1], y[1], z[1], x[2], y[2], z[2]];
}

export function parseRbxl(data: Uint8Array): Inst[] {
  const magic = new TextDecoder().decode(data.subarray(0, 8));
  if (magic !== "<roblox!") throw new Error("Not a binary Roblox place file");
  const r = new Reader(data);
  r.pos = 32;
  type ClassInfo = { name: string; refs: number[] };
  const classes = new Map<number, ClassInfo>();
  const insts = new Map<number, Inst>();
  const parentLinks: [number, number][] = [];

  while (!r.eof) {
    const name = new TextDecoder().decode(r.bytes(4));
    const compLen = r.u32();
    const uncompLen = r.u32();
    r.pos += 4;
    let payload: Uint8Array;
    if (compLen === 0) {
      payload = r.bytes(uncompLen);
    } else {
      const comp = r.bytes(compLen);
      if (comp[0] === 0x28 && comp[1] === 0xb5 && comp[2] === 0x2f && comp[3] === 0xfd) {
        throw new Error("ZSTD-compressed rbxl chunks are not supported. Save the place as .rbxlx instead.");
      }
      payload = lz4Decode(comp, uncompLen);
    }
    const c = new Reader(payload);
    if (name === "INST") {
      const classId = c.i32();
      const className = c.str();
      const fmt = c.u8();
      const count = c.u32();
      const refs = c.referents(count);
      if (fmt === 1) c.bytes(count);
      classes.set(classId, { name: className, refs });
      for (const ref of refs) insts.set(ref, { cls: className, props: {}, children: [], parent: null });
    } else if (name === "PROP") {
      const classId = c.i32();
      const propName = c.str();
      const typeId = c.u8();
      const info = classes.get(classId);
      if (!info) continue;
      const n = info.refs.length;
      const values = readPropValues(c, typeId, n);
      if (!values) continue;
      for (let i = 0; i < n; i++) {
        const inst = insts.get(info.refs[i]);
        if (inst && values[i] !== undefined) inst.props[propName] = values[i];
      }
    } else if (name === "PRNT") {
      c.u8();
      const count = c.u32();
      const children = c.referents(count);
      const parents = c.referents(count);
      for (let i = 0; i < count; i++) parentLinks.push([children[i], parents[i]]);
    } else if (name === "END\0") {
      break;
    }
  }
  const roots: Inst[] = [];
  for (const [child, parent] of parentLinks) {
    const ci = insts.get(child);
    if (!ci) continue;
    const pi = parent === -1 ? null : insts.get(parent) ?? null;
    ci.parent = pi;
    if (pi) pi.children.push(ci);
    else roots.push(ci);
  }
  for (const inst of insts.values()) if (!inst.parent && !roots.includes(inst)) roots.push(inst);
  return roots;
}

function readPropValues(c: Reader, typeId: number, n: number): unknown[] | null {
  try {
    switch (typeId) {
      case 0x01: {
        const out: string[] = [];
        for (let i = 0; i < n; i++) out.push(c.str());
        return out;
      }
      case 0x02: {
        const out: boolean[] = [];
        for (let i = 0; i < n; i++) out.push(c.u8() !== 0);
        return out;
      }
      case 0x03:
        return c.interleavedI32(n);
      case 0x04:
        return c.interleavedF32(n);
      case 0x05: {
        const out: number[] = [];
        for (let i = 0; i < n; i++) {
          out.push(c.dv.getFloat64(c.pos, true));
          c.pos += 8;
        }
        return out;
      }
      case 0x0b:
        return c.interleavedU32(n);
      case 0x0c: {
        const R = c.interleavedF32(n), G = c.interleavedF32(n), B = c.interleavedF32(n);
        return R.map((_, i) => rgbToHex(R[i], G[i], B[i]));
      }
      case 0x0e: {
        const X = c.interleavedF32(n), Y = c.interleavedF32(n), Z = c.interleavedF32(n);
        return X.map((_, i) => [X[i], Y[i], Z[i]]);
      }
      case 0x10: {
        const rots: number[][] = [];
        for (let i = 0; i < n; i++) {
          const id = c.u8();
          if (id === 0) {
            const m: number[] = [];
            for (let k = 0; k < 9; k++) m.push(c.f32());
            rots.push(m);
          } else rots.push(basicRotation(id));
        }
        const X = c.interleavedF32(n), Y = c.interleavedF32(n), Z = c.interleavedF32(n);
        return rots.map((m, i) => [X[i], Y[i], Z[i], ...m]);
      }
      case 0x12:
        return c.interleavedU32(n);
      case 0x16: {
        const out: string[] = [];
        for (let i = 0; i < n; i++) {
          const count = c.u32();
          let first = "#ffffff";
          for (let k = 0; k < count; k++) {
            c.f32();
            const r = c.f32(), g = c.f32(), b = c.f32();
            c.f32();
            if (k === 0) first = rgbToHex(r, g, b);
          }
          out.push(first);
        }
        return out;
      }
      case 0x17: {
        const out: number[][] = [];
        for (let i = 0; i < n; i++) out.push([c.f32(), c.f32()]);
        return out;
      }
      case 0x1a: {
        const R = c.bytes(n), G = c.bytes(n), B = c.bytes(n);
        const out: string[] = [];
        for (let i = 0; i < n; i++) out.push(rgb255ToHex(R[i], G[i], B[i]));
        return out;
      }
      default:
        return null;
    }
  } catch {
    return null;
  }
}

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

function clamp01(v: number) {
  return Math.max(0, Math.min(1, Number.isFinite(v) ? v : 0));
}
function rgbToHex(r: number, g: number, b: number) {
  return rgb255ToHex(Math.round(clamp01(r) * 255), Math.round(clamp01(g) * 255), Math.round(clamp01(b) * 255));
}
function rgb255ToHex(r: number, g: number, b: number) {
  return "#" + [r, g, b].map((v) => (v & 255).toString(16).padStart(2, "0")).join("");
}
function argbToHex(v: number) {
  return rgb255ToHex((v >>> 16) & 255, (v >>> 8) & 255, v & 255);
}

/* ------------------------------------------------------------------ */
/* Convert instance tree to world                                      */
/* ------------------------------------------------------------------ */

const MAX_PARTS = 8000;

export function instancesToWorld(roots: Inst[]): WorldData {
  const parts: WorldPart[] = [];
  const stats = { parts: 0, models: 0, scripts: 0, particles: 0, images: 0, other: 0 };
  const scripts: { name: string; cls: string; source: string }[] = [];
  let counter = 0;

  const walk = (inst: Inst, inWorkspace: boolean) => {
    const cls = inst.cls;
    const ws = inWorkspace || cls === "Workspace";
    if (SCRIPT_CLASSES.has(cls)) {
      stats.scripts++;
      if (scripts.length < 200) {
        scripts.push({
          name: String(inst.props.Name ?? cls),
          cls,
          source: String(inst.props.Source ?? "").slice(0, 20000),
        });
      }
    } else if (PARTICLE_CLASSES.has(cls)) stats.particles++;
    else if (IMAGE_CLASSES.has(cls)) stats.images++;
    else if (cls === "Model" || cls === "Folder") stats.models++;
    else if (PART_CLASSES.has(cls)) {
      stats.parts++;
      if (ws && parts.length < MAX_PARTS) {
        const p = instToPart(inst, `p${counter++}`);
        if (p) parts.push(p);
      }
    } else stats.other++;
    for (const ch of inst.children) walk(ch, ws);
  };
  const hasWorkspace = roots.some((r) => r.cls === "Workspace");
  for (const r of roots) walk(r, !hasWorkspace);
  if (parts.length === 0) return { ...defaultWorld(), stats, scripts };
  if (!parts.some((p) => p.spawn)) {
    // Ensure there's always a spawn point: put one on top of the biggest part.
    const biggest = parts.reduce((a, b) => (a.size[0] * a.size[2] > b.size[0] * b.size[2] ? a : b));
    parts.push({
      id: "spawn_auto",
      name: "SpawnLocation",
      cls: "SpawnLocation",
      shape: "block",
      cf: [biggest.cf[0], biggest.cf[1] + biggest.size[1] / 2 + 0.5, biggest.cf[2], 1, 0, 0, 0, 1, 0, 0, 0, 1],
      size: [12, 1, 12],
      color: "#a3a2a5",
      material: "Plastic",
      transparency: 0,
      anchored: true,
      canCollide: true,
      spawn: true,
    });
  }
  return { parts, stats, scripts };
}

function instToPart(inst: Inst, id: string): WorldPart | null {
  const p = inst.props;
  const cf = (p.CFrame ?? p.CoordinateFrame) as number[] | undefined;
  const size = (p.size ?? p.Size) as number[] | undefined;
  if (!cf || cf.length < 12 || !size || size.length < 3) return null;
  let color = "#a3a2a5";
  if (typeof p.Color3uint8 === "string") color = p.Color3uint8;
  else if (typeof p.Color === "string") color = p.Color;
  else if (typeof p.BrickColor === "number") color = "#" + (BRICK[p.BrickColor] ?? "a3a2a5");
  const matRaw = p.Material;
  const material = typeof matRaw === "number" ? MATERIALS[matRaw] ?? "Plastic" : "Plastic";
  const cls = inst.cls;
  let shape: WorldPart["shape"] = "block";
  if (cls === "WedgePart") shape = "wedge";
  else if (cls === "CornerWedgePart") shape = "cornerwedge";
  else if (cls === "TrussPart") shape = "truss";
  else if (cls === "Part") {
    const s = (p.shape ?? p.Shape) as number | undefined;
    if (s === 0) shape = "ball";
    else if (s === 2) shape = "cylinder";
    else if (s === 3) shape = "wedge";
    else if (s === 4) shape = "cornerwedge";
  }
  let particles: WorldPart["particles"] = null;
  let decals = 0;
  for (const ch of inst.children) {
    if (ch.cls === "ParticleEmitter" || ch.cls === "Fire" || ch.cls === "Smoke" || ch.cls === "Sparkles") {
      const lifetime = ch.props.Lifetime as number[] | undefined;
      const speed = ch.props.Speed as number[] | undefined;
      const c =
        typeof ch.props.Color === "string"
          ? ch.props.Color
          : ch.cls === "Fire"
            ? "#ff8a2a"
            : ch.cls === "Smoke"
              ? "#bdbdbd"
              : "#fff6a8";
      particles = {
        color: c,
        rate: Math.min(60, Number(ch.props.Rate ?? 20) || 20),
        lifetime: lifetime ? Math.max(0.3, (lifetime[0] + lifetime[1]) / 2) : 2,
        speed: speed ? (speed[0] + speed[1]) / 2 : 5,
      };
    }
    if (ch.cls === "Decal" || ch.cls === "Texture") decals++;
  }
  const t = clamp01(Number(p.Transparency ?? 0));
  return {
    id,
    name: String(p.Name ?? cls),
    cls,
    shape,
    cf: cf.slice(0, 12).map((v) => (Number.isFinite(v) ? +v.toFixed(4) : 0)),
    size: [Math.abs(size[0]) || 0.05, Math.abs(size[1]) || 0.05, Math.abs(size[2]) || 0.05].map((v) => +v.toFixed(4)) as [
      number,
      number,
      number,
    ],
    color,
    material,
    transparency: t,
    anchored: p.Anchored !== false,
    canCollide: p.CanCollide !== false && t < 1,
    spawn: cls === "SpawnLocation",
    seat: cls === "Seat" || cls === "VehicleSeat",
    particles,
    decals: decals || undefined,
  };
}

export function parsePlaceFile(name: string, data: Uint8Array): WorldData {
  const lower = name.toLowerCase();
  const head = new TextDecoder().decode(data.subarray(0, 8));
  let roots: Inst[];
  if (head === "<roblox!") roots = parseRbxl(data);
  else if (lower.endsWith(".rbxlx") || lower.endsWith(".rbxmx") || head.trimStart().startsWith("<")) {
    roots = parseRbxlx(new TextDecoder().decode(data));
  } else roots = parseRbxl(data);
  return instancesToWorld(roots);
}

/* ------------------------------------------------------------------ */
/* Default world                                                       */
/* ------------------------------------------------------------------ */

export function defaultWorld(): WorldData {
  const parts: WorldPart[] = [
    {
      id: "baseplate",
      name: "Baseplate",
      cls: "Part",
      shape: "block",
      cf: [0, -10, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1],
      size: [512, 20, 512],
      color: "#635f62",
      material: "Plastic",
      transparency: 0,
      anchored: true,
      canCollide: true,
    },
    {
      id: "spawn",
      name: "SpawnLocation",
      cls: "SpawnLocation",
      shape: "block",
      cf: [0, 0.5, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1],
      size: [12, 1, 12],
      color: "#a3a2a5",
      material: "Plastic",
      transparency: 0,
      anchored: true,
      canCollide: true,
      spawn: true,
    },
  ];
  return { parts, stats: { parts: 2, models: 0, scripts: 0, particles: 0, images: 0, other: 0 }, scripts: [] };
}
