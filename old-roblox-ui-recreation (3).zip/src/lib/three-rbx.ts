"use client";
import * as THREE from "three";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";
import { computeBoundsTree, disposeBoundsTree, acceleratedRaycast } from "three-mesh-bvh";
import type { AvatarData, WorldData, WorldPart } from "@/db/schema";

// Enable BVH accelerated raycasts globally.
(THREE.BufferGeometry.prototype as unknown as { computeBoundsTree: unknown }).computeBoundsTree = computeBoundsTree;
(THREE.BufferGeometry.prototype as unknown as { disposeBoundsTree: unknown }).disposeBoundsTree = disposeBoundsTree;
THREE.Mesh.prototype.raycast = acceleratedRaycast;

/* ------------------------------------------------------------------ */
/* Character                                                           */
/* ------------------------------------------------------------------ */

export type CharacterRig = {
  group: THREE.Group;
  torso: THREE.Mesh;
  head: THREE.Mesh;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  phase: number;
};

const faceCache = new Map<string, THREE.CanvasTexture>();

function faceTexture(face: AvatarData["face"]) {
  const cached = faceCache.get(face);
  if (cached) return cached;
  const c = document.createElement("canvas");
  c.width = 128;
  c.height = 128;
  const ctx = c.getContext("2d")!;
  ctx.clearRect(0, 0, 128, 128);
  ctx.fillStyle = "#000";
  // eyes
  ctx.beginPath();
  ctx.ellipse(44, 52, 7, 12, 0, 0, Math.PI * 2);
  ctx.ellipse(84, 52, 7, 12, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.lineWidth = 6;
  ctx.strokeStyle = "#000";
  ctx.lineCap = "round";
  ctx.beginPath();
  if (face === "happy") {
    ctx.arc(64, 74, 22, 0.15 * Math.PI, 0.85 * Math.PI);
  } else if (face === "serious") {
    ctx.moveTo(46, 88);
    ctx.lineTo(82, 88);
  } else {
    ctx.arc(64, 70, 24, 0.2 * Math.PI, 0.8 * Math.PI);
  }
  ctx.stroke();
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  faceCache.set(face, tex);
  return tex;
}

function limb(color: string, sleeve: string | null): THREE.Group {
  const pivot = new THREE.Group();
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(1, 2, 1), new THREE.MeshLambertMaterial({ color }));
  mesh.position.y = -1;
  mesh.castShadow = true;
  pivot.add(mesh);
  if (sleeve) {
    const s = new THREE.Mesh(new THREE.BoxGeometry(1.06, 1.0, 1.06), new THREE.MeshLambertMaterial({ color: sleeve }));
    s.position.y = -0.5;
    pivot.add(s);
  }
  return pivot;
}

export function buildCharacter(avatar: AvatarData): CharacterRig {
  const group = new THREE.Group();
  const torsoColor = avatar.shirt ?? avatar.torso;
  const torso = new THREE.Mesh(new THREE.BoxGeometry(2, 2, 1), new THREE.MeshLambertMaterial({ color: torsoColor }));
  torso.position.y = 3;
  torso.castShadow = true;
  group.add(torso);
  if (avatar.shirt) {
    const belt = new THREE.Mesh(new THREE.BoxGeometry(2.04, 0.5, 1.04), new THREE.MeshLambertMaterial({ color: avatar.pants ?? avatar.torso }));
    belt.position.y = 2.25;
    group.add(belt);
  }

  const headMat = new THREE.MeshLambertMaterial({ color: avatar.head });
  const faceMat = new THREE.MeshLambertMaterial({ color: avatar.head, map: faceTexture(avatar.face), transparent: false });
  const head = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.2, 1.2), [headMat, headMat, headMat, headMat, faceMat, headMat]);
  head.position.y = 4.6;
  head.castShadow = true;
  group.add(head);

  const leftArm = limb(avatar.leftArm, avatar.shirt);
  leftArm.position.set(-1.5, 4, 0);
  const rightArm = limb(avatar.rightArm, avatar.shirt);
  rightArm.position.set(1.5, 4, 0);
  const leftLeg = limb(avatar.pants ?? avatar.leftLeg, null);
  leftLeg.position.set(-0.5, 2, 0);
  const rightLeg = limb(avatar.pants ?? avatar.rightLeg, null);
  rightLeg.position.set(0.5, 2, 0);
  group.add(leftArm, rightArm, leftLeg, rightLeg);

  if (avatar.hat !== "none") {
    const hat = new THREE.Group();
    if (avatar.hat === "cap") {
      const top = new THREE.Mesh(new THREE.CylinderGeometry(0.72, 0.75, 0.4, 16), new THREE.MeshLambertMaterial({ color: "#c4281c" }));
      top.position.y = 0.2;
      const brim = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.08, 0.7), new THREE.MeshLambertMaterial({ color: "#c4281c" }));
      brim.position.set(0, 0.02, 0.85);
      hat.add(top, brim);
    } else if (avatar.hat === "tophat") {
      const brim = new THREE.Mesh(new THREE.CylinderGeometry(1.0, 1.0, 0.1, 20), new THREE.MeshLambertMaterial({ color: "#1b2a35" }));
      const top = new THREE.Mesh(new THREE.CylinderGeometry(0.65, 0.65, 1.3, 20), new THREE.MeshLambertMaterial({ color: "#1b2a35" }));
      top.position.y = 0.7;
      const band = new THREE.Mesh(new THREE.CylinderGeometry(0.67, 0.67, 0.2, 20), new THREE.MeshLambertMaterial({ color: "#c4281c" }));
      band.position.y = 0.2;
      hat.add(brim, top, band);
    } else {
      const band = new THREE.Mesh(new THREE.TorusGeometry(0.7, 0.08, 8, 20), new THREE.MeshLambertMaterial({ color: "#0d69ac" }));
      band.rotation.x = Math.PI / 2;
      const brim = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.08, 0.7), new THREE.MeshLambertMaterial({ color: "#0d69ac" }));
      brim.position.set(0, 0, 0.9);
      hat.add(band, brim);
    }
    hat.position.y = 5.2;
    group.add(hat);
  }

  return { group, torso, head, leftArm, rightArm, leftLeg, rightLeg, phase: Math.random() * 10 };
}

export function animateCharacter(rig: CharacterRig, dt: number, moving: boolean, airborne: boolean) {
  if (airborne) {
    rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, -Math.PI * 0.95, 0.2);
    rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, -Math.PI * 0.95, 0.2);
    rig.leftLeg.rotation.x = THREE.MathUtils.lerp(rig.leftLeg.rotation.x, 0.3, 0.2);
    rig.rightLeg.rotation.x = THREE.MathUtils.lerp(rig.rightLeg.rotation.x, -0.3, 0.2);
    return;
  }
  if (moving) {
    rig.phase += dt * 10;
    const s = Math.sin(rig.phase) * 0.9;
    rig.leftArm.rotation.x = s;
    rig.rightArm.rotation.x = -s;
    rig.leftLeg.rotation.x = -s;
    rig.rightLeg.rotation.x = s;
  } else {
    const k = 0.15;
    rig.leftArm.rotation.x = THREE.MathUtils.lerp(rig.leftArm.rotation.x, 0, k);
    rig.rightArm.rotation.x = THREE.MathUtils.lerp(rig.rightArm.rotation.x, 0, k);
    rig.leftLeg.rotation.x = THREE.MathUtils.lerp(rig.leftLeg.rotation.x, 0, k);
    rig.rightLeg.rotation.x = THREE.MathUtils.lerp(rig.rightLeg.rotation.x, 0, k);
  }
}

/* ------------------------------------------------------------------ */
/* Geometry helpers                                                    */
/* ------------------------------------------------------------------ */

function wedgeGeometry(w: number, h: number, d: number) {
  const x = w / 2, y = h / 2, z = d / 2;
  // slope rises from front (-z, bottom) to back (+z, top)
  const v = [
    // bottom
    -x, -y, -z, x, -y, -z, x, -y, z, -x, -y, -z, x, -y, z, -x, -y, z,
    // back (vertical, +z)
    -x, -y, z, x, -y, z, x, y, z, -x, -y, z, x, y, z, -x, y, z,
    // slope
    -x, -y, -z, -x, y, z, x, y, z, -x, -y, -z, x, y, z, x, -y, -z,
    // left
    -x, -y, -z, -x, -y, z, -x, y, z,
    // right
    x, -y, -z, x, y, z, x, -y, z,
  ];
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(v, 3));
  g.computeVertexNormals();
  return g;
}

function cornerWedgeGeometry(w: number, h: number, d: number) {
  const x = w / 2, y = h / 2, z = d / 2;
  const apex = [x, y, z];
  const v = [
    // bottom
    -x, -y, -z, x, -y, z, x, -y, -z, -x, -y, -z, -x, -y, z, x, -y, z,
    // right vertical (x = +x)
    x, -y, -z, x, -y, z, ...apex,
    // back vertical (z = +z)
    x, -y, z, -x, -y, z, ...apex,
    // slopes
    -x, -y, -z, x, -y, -z, ...apex,
    -x, -y, z, -x, -y, -z, ...apex,
  ];
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(v, 3));
  g.computeVertexNormals();
  return g;
}

function partGeometry(p: WorldPart): THREE.BufferGeometry {
  const [w, h, d] = p.size;
  switch (p.shape) {
    case "ball":
      return new THREE.SphereGeometry(Math.min(w, h, d) / 2, 14, 10);
    case "cylinder": {
      const r = Math.min(h, d) / 2;
      const g = new THREE.CylinderGeometry(r, r, w, 16);
      g.rotateZ(Math.PI / 2);
      return g;
    }
    case "wedge":
      return wedgeGeometry(w, h, d);
    case "cornerwedge":
      return cornerWedgeGeometry(w, h, d);
    default:
      return new THREE.BoxGeometry(w, h, d);
  }
}

export function partMatrix(p: WorldPart) {
  const c = p.cf;
  const m = new THREE.Matrix4();
  m.set(c[3], c[4], c[5], c[0], c[6], c[7], c[8], c[1], c[9], c[10], c[11], c[2], 0, 0, 0, 1);
  return m;
}

function materialFor(p: WorldPart): THREE.Material {
  const t = p.transparency;
  const common = { color: p.color, transparent: t > 0, opacity: 1 - t, side: THREE.FrontSide as THREE.Side };
  if (p.material === "Neon") return new THREE.MeshBasicMaterial(common);
  if (p.material === "ForceField") return new THREE.MeshBasicMaterial({ ...common, transparent: true, opacity: 0.4 });
  if (p.material === "Glass") return new THREE.MeshPhongMaterial({ ...common, transparent: true, opacity: Math.min(1 - t, 0.6), shininess: 120 });
  if (p.material === "SmoothPlastic" || p.material === "Metal" || p.material === "Foil" || p.material === "DiamondPlate") {
    return new THREE.MeshPhongMaterial({ ...common, shininess: 60, specular: new THREE.Color("#666") });
  }
  return new THREE.MeshLambertMaterial(common);
}

/* ------------------------------------------------------------------ */
/* World                                                               */
/* ------------------------------------------------------------------ */

export type Collider = {
  id: string;
  inv: THREE.Matrix4;
  mat: THREE.Matrix4;
  half: THREE.Vector3;
  center: THREE.Vector3;
  radius: number;
  box: boolean; // true for shapes that get horizontal OBB collision
  dynamic: boolean;
};

export type BuiltWorld = {
  root: THREE.Group;
  staticMeshes: THREE.Mesh[];
  dynamicMeshes: Map<string, THREE.Mesh>;
  colliders: Collider[];
  spawns: THREE.Vector3[];
  emitters: { pos: THREE.Vector3; cfg: NonNullable<WorldPart["particles"]>; points: THREE.Points; vel: Float32Array; life: Float32Array }[];
  raycastTargets: THREE.Object3D[];
};

export function buildWorld(world: WorldData, scene: THREE.Scene): BuiltWorld {
  const root = new THREE.Group();
  const byKey = new Map<string, { mat: THREE.Material; geos: THREE.BufferGeometry[] }>();
  const colliders: Collider[] = [];
  const spawns: THREE.Vector3[] = [];
  const dynamicMeshes = new Map<string, THREE.Mesh>();
  const emitters: BuiltWorld["emitters"] = [];
  const staticMeshes: THREE.Mesh[] = [];

  for (const p of world.parts) {
    const m = partMatrix(p);
    const pos = new THREE.Vector3().setFromMatrixPosition(m);
    if (p.spawn) spawns.push(new THREE.Vector3(pos.x, pos.y + p.size[1] / 2, pos.z));
    if (p.canCollide || p.spawn) {
      colliders.push({
        id: p.id,
        inv: m.clone().invert(),
        mat: m.clone(),
        half: new THREE.Vector3(p.size[0] / 2, p.size[1] / 2, p.size[2] / 2),
        center: pos.clone(),
        radius: Math.hypot(p.size[0], p.size[1], p.size[2]) / 2,
        box: p.shape === "block" || p.shape === "truss",
        dynamic: !p.anchored,
      });
    }
    if (p.transparency >= 1) continue;
    const geo = partGeometry(p);
    if (p.spawn) {
      // classic spawn look: grey pad with darker top decal ring
      geo.applyMatrix4(m);
      const mesh = new THREE.Mesh(geo, materialFor(p));
      root.add(mesh);
      staticMeshes.push(mesh);
      continue;
    }
    if (!p.anchored) {
      const mesh = new THREE.Mesh(geo, materialFor(p));
      mesh.applyMatrix4(m);
      mesh.userData.half = p.size[1] / 2;
      root.add(mesh);
      dynamicMeshes.set(p.id, mesh);
    } else {
      geo.applyMatrix4(m);
      const key = `${p.color}|${p.material}|${p.transparency.toFixed(2)}`;
      let entry = byKey.get(key);
      if (!entry) {
        entry = { mat: materialFor(p), geos: [] };
        byKey.set(key, entry);
      }
      entry.geos.push(geo);
    }
    if (p.particles) {
      const count = 60;
      const positions = new Float32Array(count * 3);
      const vel = new Float32Array(count * 3);
      const life = new Float32Array(count);
      for (let i = 0; i < count; i++) life[i] = Math.random() * p.particles.lifetime;
      const pg = new THREE.BufferGeometry();
      pg.setAttribute("position", new THREE.BufferAttribute(positions, 3));
      const points = new THREE.Points(
        pg,
        new THREE.PointsMaterial({ color: p.particles.color, size: 0.8, transparent: true, opacity: 0.85, depthWrite: false }),
      );
      points.frustumCulled = false;
      root.add(points);
      emitters.push({ pos: new THREE.Vector3(pos.x, pos.y + p.size[1] / 2, pos.z), cfg: p.particles, points, vel, life });
    }
  }

  for (const { mat, geos } of byKey.values()) {
    const merged = geos.length === 1 ? geos[0] : mergeGeometries(geos, false);
    if (!merged) continue;
    const mesh = new THREE.Mesh(merged, mat);
    (merged as unknown as { computeBoundsTree: () => void }).computeBoundsTree();
    mesh.receiveShadow = true;
    root.add(mesh);
    staticMeshes.push(mesh);
  }
  for (const mesh of staticMeshes) {
    if (!(mesh.geometry as unknown as { boundsTree?: unknown }).boundsTree) {
      (mesh.geometry as unknown as { computeBoundsTree: () => void }).computeBoundsTree();
    }
  }
  scene.add(root);
  return {
    root,
    staticMeshes,
    dynamicMeshes,
    colliders,
    spawns: spawns.length ? spawns : [new THREE.Vector3(0, 5, 0)],
    emitters,
    raycastTargets: [...staticMeshes, ...dynamicMeshes.values()],
  };
}

export function updateEmitters(built: BuiltWorld, dt: number) {
  for (const e of built.emitters) {
    const arr = e.points.geometry.getAttribute("position") as THREE.BufferAttribute;
    const a = arr.array as Float32Array;
    for (let i = 0; i < e.life.length; i++) {
      e.life[i] -= dt;
      if (e.life[i] <= 0) {
        e.life[i] = e.cfg.lifetime * (0.6 + Math.random() * 0.4);
        a[i * 3] = e.pos.x + (Math.random() - 0.5) * 2;
        a[i * 3 + 1] = e.pos.y;
        a[i * 3 + 2] = e.pos.z + (Math.random() - 0.5) * 2;
        e.vel[i * 3] = (Math.random() - 0.5) * 2;
        e.vel[i * 3 + 1] = e.cfg.speed * (0.5 + Math.random() * 0.5);
        e.vel[i * 3 + 2] = (Math.random() - 0.5) * 2;
      }
      a[i * 3] += e.vel[i * 3] * dt;
      a[i * 3 + 1] += e.vel[i * 3 + 1] * dt;
      a[i * 3 + 2] += e.vel[i * 3 + 2] * dt;
    }
    arr.needsUpdate = true;
  }
}

/* ------------------------------------------------------------------ */
/* Collision: sphere vs OBB push-out                                   */
/* ------------------------------------------------------------------ */

const _local = new THREE.Vector3();
const _closest = new THREE.Vector3();
const _n = new THREE.Vector3();

export function resolveSphere(colliders: Collider[], center: THREE.Vector3, radius: number, out: THREE.Vector3): boolean {
  let hit = false;
  for (const c of colliders) {
    if (!c.box) continue;
    const dx = c.center.x - center.x, dy = c.center.y - center.y, dz = c.center.z - center.z;
    const rr = c.radius + radius;
    if (dx * dx + dy * dy + dz * dz > rr * rr) continue;
    _local.copy(center).applyMatrix4(c.inv);
    _closest.set(
      THREE.MathUtils.clamp(_local.x, -c.half.x, c.half.x),
      THREE.MathUtils.clamp(_local.y, -c.half.y, c.half.y),
      THREE.MathUtils.clamp(_local.z, -c.half.z, c.half.z),
    );
    _n.subVectors(_local, _closest);
    const d = _n.length();
    if (d >= radius) continue;
    if (d < 1e-5) {
      // Center inside the box: push out along the smallest penetration axis.
      const px = c.half.x - Math.abs(_local.x), py = c.half.y - Math.abs(_local.y), pz = c.half.z - Math.abs(_local.z);
      if (px <= py && px <= pz) _n.set(Math.sign(_local.x) || 1, 0, 0).multiplyScalar(px + radius);
      else if (py <= pz) _n.set(0, Math.sign(_local.y) || 1, 0).multiplyScalar(py + radius);
      else _n.set(0, 0, Math.sign(_local.z) || 1).multiplyScalar(pz + radius);
    } else {
      _n.multiplyScalar((radius - d) / d);
    }
    // transform push vector back to world (rotation only); transformDirection normalizes so keep magnitude
    const len = _n.length();
    _n.transformDirection(c.mat).multiplyScalar(len);
    center.add(_n);
    out.add(_n);
    hit = true;
  }
  return hit;
}

export function updateColliderFromMesh(c: Collider, mesh: THREE.Mesh) {
  mesh.updateMatrixWorld();
  c.mat.copy(mesh.matrixWorld);
  c.inv.copy(mesh.matrixWorld).invert();
  c.center.setFromMatrixPosition(mesh.matrixWorld);
}

/* ------------------------------------------------------------------ */
/* Avatar thumbnails (shared offscreen renderer)                       */
/* ------------------------------------------------------------------ */

let thumbRenderer: THREE.WebGLRenderer | null = null;
const thumbCache = new Map<string, string>();

export function renderAvatarThumb(avatar: AvatarData, mode: "bust" | "full", size = 256): string {
  const key = `${mode}:${size}:${JSON.stringify(avatar)}`;
  const cached = thumbCache.get(key);
  if (cached) return cached;
  if (!thumbRenderer) {
    thumbRenderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, preserveDrawingBuffer: true });
    thumbRenderer.setPixelRatio(1);
  }
  thumbRenderer.setSize(size, size, false);
  const scene = new THREE.Scene();
  scene.add(new THREE.AmbientLight(0xffffff, 1.6));
  const dir = new THREE.DirectionalLight(0xffffff, 1.6);
  dir.position.set(3, 6, 5);
  scene.add(dir);
  const rig = buildCharacter(avatar);
  rig.group.rotation.y = -0.35;
  scene.add(rig.group);
  const cam = new THREE.PerspectiveCamera(30, 1, 0.1, 100);
  if (mode === "bust") {
    cam.position.set(0.9, 4.9, 6.2);
    cam.lookAt(0, 4.0, 0);
  } else {
    cam.position.set(2.2, 4.2, 13);
    cam.lookAt(0, 2.6, 0);
  }
  thumbRenderer.render(scene, cam);
  const url = thumbRenderer.domElement.toDataURL("image/png");
  thumbCache.set(key, url);
  return url;
}
