import {
  pgTable,
  serial,
  text,
  integer,
  timestamp,
  boolean,
  jsonb,
  primaryKey,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export type AvatarData = {
  head: string;
  torso: string;
  leftArm: string;
  rightArm: string;
  leftLeg: string;
  rightLeg: string;
  shirt: string | null;
  pants: string | null;
  hat: "none" | "cap" | "tophat" | "visor";
  face: "smile" | "happy" | "serious";
};

export type WorldPart = {
  id: string;
  name: string;
  cls: string;
  shape: "block" | "ball" | "cylinder" | "wedge" | "cornerwedge" | "truss";
  cf: number[]; // x y z r00 r01 r02 r10 r11 r12 r20 r21 r22
  size: [number, number, number];
  color: string;
  material: string;
  transparency: number;
  anchored: boolean;
  canCollide: boolean;
  spawn?: boolean;
  seat?: boolean;
  particles?: { color: string; rate: number; lifetime: number; speed: number } | null;
  decals?: number;
};

export type WorldData = {
  parts: WorldPart[];
  stats: { parts: number; models: number; scripts: number; particles: number; images: number; other: number };
  scripts?: { name: string; cls: string; source: string }[];
};

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  birthday: text("birthday").notNull(),
  gender: text("gender").notNull().default("male"),
  robux: integer("robux").notNull().default(100),
  description: text("description").notNull().default(""),
  language: text("language").notNull().default("en"),
  avatar: jsonb("avatar").$type<AvatarData>().notNull(),
  presence: text("presence").notNull().default("offline"),
  lastSeen: timestamp("last_seen", { withTimezone: true }).notNull().defaultNow(),
  currentPlaceId: integer("current_place_id"),
  lastRobuxClaim: text("last_robux_claim"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const sessions = pgTable("sessions", {
  id: text("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const friendships = pgTable(
  "friendships",
  {
    id: serial("id").primaryKey(),
    requesterId: integer("requester_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    addresseeId: integer("addressee_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    status: text("status").notNull().default("pending"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("friendships_pair_idx").on(t.requesterId, t.addresseeId)],
);

export const follows = pgTable(
  "follows",
  {
    followerId: integer("follower_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    followingId: integer("following_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
  },
  (t) => [primaryKey({ columns: [t.followerId, t.followingId] })],
);

export const places = pgTable("places", {
  id: serial("id").primaryKey(),
  ownerId: integer("owner_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  thumbnail: text("thumbnail"),
  world: jsonb("world").$type<WorldData>().notNull(),
  visits: integer("visits").notNull().default(0),
  isPublic: boolean("is_public").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const placeLikes = pgTable(
  "place_likes",
  {
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    placeId: integer("place_id")
      .notNull()
      .references(() => places.id, { onDelete: "cascade" }),
  },
  (t) => [primaryKey({ columns: [t.userId, t.placeId] })],
);

export const placeFavorites = pgTable(
  "place_favorites",
  {
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    placeId: integer("place_id")
      .notNull()
      .references(() => places.id, { onDelete: "cascade" }),
  },
  (t) => [primaryKey({ columns: [t.userId, t.placeId] })],
);

export const placeVisits = pgTable(
  "place_visits",
  {
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    placeId: integer("place_id")
      .notNull()
      .references(() => places.id, { onDelete: "cascade" }),
    lastPlayed: timestamp("last_played", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.userId, t.placeId] })],
);

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  receiverId: integer("receiver_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  text: text("text").notNull(),
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
