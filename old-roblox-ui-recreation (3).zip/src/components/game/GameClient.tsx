"use client";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import type { AvatarData, WorldData } from "@/db/schema";
import type { Vector3 } from "three";
import type { CharacterRig } from "@/lib/three-rbx";
import { AddPersonIcon, BurgerIcon, ChatIcon, CloseIcon, JumpIcon, RobloxMark } from "@/components/Icons";

type Me = { id: number; username: string; avatar: AvatarData };
type PlayerInfo = { id: string; userId: number; username: string; avatar: AvatarData };
type PlaceMeta = { id: number; name: string; thumbnail: string | null; ownerName: string; ownerId: number; world: WorldData };
type ChatMsg = { id: string; username: string; text: string; ts: number };

const GRAVITY = 196.2;
const WALK_SPEED = 16;
const JUMP_POWER = 50;

export default function GameClient({ me, placeId }: { me: Me; placeId: number }) {
  const router = useRouter();
  const mountRef = useRef<HTMLDivElement>(null);
  const overlayRef = useRef<HTMLDivElement>(null);
  const knobRef = useRef<HTMLDivElement>(null);
  const joyRef = useRef<HTMLDivElement>(null);

  const [meta, setMeta] = useState<PlaceMeta | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [players, setPlayers] = useState<PlayerInfo[]>([]);
  const [hostId, setHostId] = useState<string | null>(null);
  const [selfId, setSelfId] = useState<string | null>(null);
  const [chatLog, setChatLog] = useState<ChatMsg[]>([]);
  const [chatText, setChatText] = useState("");
  const [isTouch, setIsTouch] = useState(false);
  const [friendState, setFriendState] = useState<Record<number, string>>({});

  // shared mutable input state
  const input = useRef({ x: 0, y: 0, jump: false, keys: new Set<string>() });
  const socketRef = useRef<import("socket.io-client").Socket | null>(null);
  const leaveRef = useRef<() => void>(() => {});

  useEffect(() => {
    setIsTouch("ontouchstart" in window || navigator.maxTouchPoints > 0);
    fetch(`/api/places/${placeId}?world=1`)
      .then((r) => r.json())
      .then((j) => {
        if (!j.place) throw new Error(j.error ?? "Place not found");
        setMeta(j.place);
      })
      .catch((e) => setError(e.message));
  }, [placeId]);

  useEffect(() => {
    if (!meta || !mountRef.current) return;
    const mount = mountRef.current;
    const overlay = overlayRef.current!;
    let disposed = false;
    let cleanup: (() => void) | null = null;

    (async () => {
      const [THREE, rbx, { io }] = await Promise.all([import("three"), import("@/lib/three-rbx"), import("socket.io-client")]);
      if (disposed) return;

      /* ---------------- renderer / scene ---------------- */
      const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.75));
      renderer.setSize(mount.clientWidth, mount.clientHeight);
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      mount.appendChild(renderer.domElement);
      const scene = new THREE.Scene();
      scene.background = new THREE.Color("#7eb2ea");
      scene.fog = new THREE.Fog("#c5daf3", 300, 1200);
      scene.add(new THREE.HemisphereLight("#dbe9ff", "#5c6b4a", 1.1));
      const sun = new THREE.DirectionalLight("#ffffff", 1.6);
      sun.position.set(60, 120, 40);
      scene.add(sun);
      const camera = new THREE.PerspectiveCamera(70, mount.clientWidth / mount.clientHeight, 0.1, 2000);

      const built = rbx.buildWorld(meta.world, scene);
      const raycaster = new THREE.Raycaster();
      (raycaster as unknown as { firstHitOnly: boolean }).firstHitOnly = true;
      raycaster.far = 4;
      const DOWN = new THREE.Vector3(0, -1, 0);

      /* ---------------- local character ---------------- */
      const rig = rbx.buildCharacter(me.avatar);
      scene.add(rig.group);
      const pos = new THREE.Vector3();
      const prev = new THREE.Vector3();
      let vy = 0;
      let grounded = false;
      let ry = 0;
      let moving = false;
      const respawn = () => {
        const s = built.spawns[Math.floor(Math.random() * built.spawns.length)];
        pos.set(s.x + (Math.random() - 0.5) * 4, s.y + 0.5, s.z + (Math.random() - 0.5) * 4);
        vy = 0;
      };
      respawn();

      /* ---------------- camera ---------------- */
      let yaw = Math.PI;
      let pitch = 0.35;
      let dist = 14;
      const camTarget = new THREE.Vector3();

      /* ---------------- remote players ---------------- */
      type Remote = {
        info: PlayerInfo;
        rig: CharacterRig;
        target: Vector3;
        ry: number;
        moving: boolean;
        airborne: boolean;
        tag: HTMLDivElement;
        bubble: HTMLDivElement;
        bubbleUntil: number;
      };
      const remotes = new Map<string, Remote>();
      const makeTag = (name: string | null) => {
        const wrap = document.createElement("div");
        wrap.className = "absolute flex flex-col items-center pointer-events-none";
        wrap.style.transform = "translate(-50%, -100%)";
        wrap.style.display = "none";
        const bubble = document.createElement("div");
        bubble.className = "mb-1 max-w-[220px] rounded-lg bg-white/95 px-2 py-1 text-xs text-[#222] shadow";
        bubble.style.display = "none";
        wrap.appendChild(bubble);
        if (name) {
          const nm = document.createElement("div");
          nm.className = "text-sm font-semibold text-white";
          nm.style.textShadow = "0 0 3px #000, 0 0 3px #000";
          nm.textContent = name;
          wrap.appendChild(nm);
        }
        overlay.appendChild(wrap);
        return { wrap, bubble };
      };
      const selfTag = makeTag(null);
      let selfBubbleUntil = 0;

      const addRemote = (p: PlayerInfo) => {
        if (remotes.has(p.id)) return;
        const r = rbx.buildCharacter(p.avatar);
        scene.add(r.group);
        const spawn = built.spawns[0];
        r.group.position.set(spawn.x, spawn.y, spawn.z);
        const tag = makeTag(p.username);
        remotes.set(p.id, {
          info: p,
          rig: r,
          target: new THREE.Vector3(spawn.x, spawn.y, spawn.z),
          ry: 0,
          moving: false,
          airborne: false,
          tag: tag.wrap,
          bubble: tag.bubble,
          bubbleUntil: 0,
        });
      };
      const removeRemote = (id: string) => {
        const r = remotes.get(id);
        if (!r) return;
        scene.remove(r.rig.group);
        r.tag.remove();
        remotes.delete(id);
      };

      /* ---------------- networking (relay) ---------------- */
      await fetch("/api/socketio").catch(() => {});
      if (disposed) return;
      const socket = io({ path: "/api/socketio", transports: ["websocket", "polling"] });
      socketRef.current = socket;
      let mySocketId: string | null = null;
      let currentHost: string | null = null;
      const playerList = new Map<string, PlayerInfo>();
      const pushPlayers = () => setPlayers([...playerList.values()]);

      const applyWorld = (w: unknown) => {
        const data = w as { d?: Record<string, number[]> } | null;
        if (!data?.d) return;
        for (const [id, p] of Object.entries(data.d)) {
          const mesh = built.dynamicMeshes.get(id);
          if (!mesh) continue;
          mesh.position.set(p[0], p[1], p[2]);
          const col = built.colliders.find((c) => c.id === id);
          if (col) rbx.updateColliderFromMesh(col, mesh);
        }
      };

      socket.on("connect", () => {
        socket.emit("join", { placeId, user: { id: me.id, username: me.username, avatar: me.avatar } });
      });
      socket.on("joined", (j: { selfId: string; hostId: string; players: PlayerInfo[]; world: unknown }) => {
        mySocketId = j.selfId;
        currentHost = j.hostId;
        setSelfId(j.selfId);
        setHostId(j.hostId);
        // reconnection: reset remotes
        for (const id of [...remotes.keys()]) removeRemote(id);
        playerList.clear();
        for (const p of j.players) {
          playerList.set(p.id, p);
          if (p.id !== j.selfId) addRemote(p);
        }
        pushPlayers();
        applyWorld(j.world);
        setReady(true);
      });
      socket.on("player_joined", ({ player }: { player: PlayerInfo }) => {
        playerList.set(player.id, player);
        addRemote(player);
        pushPlayers();
      });
      socket.on("player_left", ({ id }: { id: string }) => {
        playerList.delete(id);
        removeRemote(id);
        pushPlayers();
      });
      socket.on("host", ({ hostId, world }: { hostId: string; world: unknown }) => {
        currentHost = hostId;
        setHostId(hostId);
        if (hostId !== mySocketId) applyWorld(world);
      });
      socket.on("state", (s: { id: string; p: number[]; r: number; m: number; a: number }) => {
        const r = remotes.get(s.id);
        if (!r) return;
        r.target.set(s.p[0], s.p[1], s.p[2]);
        r.ry = s.r;
        r.moving = !!s.m;
        r.airborne = !!s.a;
      });
      socket.on("world", (w: unknown) => {
        if (currentHost !== mySocketId) applyWorld(w);
      });
      socket.on("chat", (m: ChatMsg) => {
        setChatLog((l) => [...l.slice(-99), m]);
        if (m.id === mySocketId) {
          selfTag.bubble.textContent = m.text;
          selfTag.bubble.style.display = "block";
          selfBubbleUntil = performance.now() + 6000;
        } else {
          const r = remotes.get(m.id);
          if (r) {
            r.bubble.textContent = m.text;
            r.bubble.style.display = "block";
            r.bubbleUntil = performance.now() + 6000;
          }
        }
      });
      // safety: never hang on the loading screen if the relay is slow
      const readyTimer = setTimeout(() => setReady(true), 8000);

      /* ---------------- input ---------------- */
      const keys = input.current.keys;
      const onKey = (down: boolean) => (e: KeyboardEvent) => {
        if ((e.target as HTMLElement)?.tagName === "INPUT") return;
        const k = e.key.toLowerCase();
        if (down) keys.add(k);
        else keys.delete(k);
        if (k === " " && down) e.preventDefault();
      };
      const kd = onKey(true), ku = onKey(false);
      window.addEventListener("keydown", kd);
      window.addEventListener("keyup", ku);

      // camera drag on the canvas
      let dragId: number | null = null;
      let lastX = 0, lastY = 0;
      const el = renderer.domElement;
      const pd = (e: PointerEvent) => {
        if (dragId !== null) return;
        dragId = e.pointerId;
        lastX = e.clientX;
        lastY = e.clientY;
        el.setPointerCapture(e.pointerId);
      };
      const pm = (e: PointerEvent) => {
        if (e.pointerId !== dragId) return;
        yaw -= (e.clientX - lastX) * 0.006;
        pitch = THREE.MathUtils.clamp(pitch + (e.clientY - lastY) * 0.006, -0.35, 1.35);
        lastX = e.clientX;
        lastY = e.clientY;
      };
      const pu = (e: PointerEvent) => {
        if (e.pointerId === dragId) dragId = null;
      };
      const wheel = (e: WheelEvent) => {
        dist = THREE.MathUtils.clamp(dist * (1 + e.deltaY * 0.0012), 3, 45);
      };
      el.addEventListener("pointerdown", pd);
      el.addEventListener("pointermove", pm);
      el.addEventListener("pointerup", pu);
      el.addEventListener("pointercancel", pu);
      el.addEventListener("wheel", wheel, { passive: true });

      const resize = () => {
        renderer.setSize(mount.clientWidth, mount.clientHeight);
        camera.aspect = mount.clientWidth / mount.clientHeight;
        camera.updateProjectionMatrix();
      };
      window.addEventListener("resize", resize);

      /* ---------------- presence ---------------- */
      const beat = () =>
        fetch("/api/presence", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ status: "ingame", placeId }),
        }).catch(() => {});
      beat();
      fetch("/api/places", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "visit", placeId }) });
      const beatTimer = setInterval(beat, 25000);

      /* ---------------- host simulation (listen server) ---------------- */
      const dynVel = new Map<string, number>();
      let lastWorldSend = 0;
      const hostStep = (dt: number, now: number) => {
        if (currentHost !== mySocketId || built.dynamicMeshes.size === 0) return;
        const snapshot: Record<string, number[]> = {};
        for (const [id, mesh] of built.dynamicMeshes) {
          const half = (mesh.userData.half as number) ?? 0.5;
          let v = dynVel.get(id) ?? 0;
          v -= GRAVITY * dt;
          const drop = -v * dt;
          raycaster.set(new THREE.Vector3(mesh.position.x, mesh.position.y, mesh.position.z), DOWN);
          raycaster.far = half + drop + 0.05;
          const hits = raycaster.intersectObjects(built.staticMeshes, false);
          if (hits.length) {
            mesh.position.y = hits[0].point.y + half;
            v = 0;
          } else {
            mesh.position.y += v * dt;
          }
          if (mesh.position.y < -300) {
            mesh.position.y = 200;
            v = 0;
          }
          dynVel.set(id, v);
          const col = built.colliders.find((c) => c.id === id);
          if (col) rbx.updateColliderFromMesh(col, mesh);
          snapshot[id] = [+mesh.position.x.toFixed(2), +mesh.position.y.toFixed(2), +mesh.position.z.toFixed(2)];
        }
        if (now - lastWorldSend > 200) {
          lastWorldSend = now;
          socket.emit("world", { d: snapshot });
        }
      };

      /* ---------------- main loop ---------------- */
      const fwd = new THREE.Vector3();
      const right = new THREE.Vector3();
      const dir = new THREE.Vector3();
      const sphere = new THREE.Vector3();
      const push = new THREE.Vector3();
      const proj = new THREE.Vector3();
      let last = performance.now();
      let lastSend = 0;
      let raf = 0;

      const step = () => {
        raf = requestAnimationFrame(step);
        const now = performance.now();
        const dt = Math.min(0.05, (now - last) / 1000);
        last = now;

        // ---- input vector
        let ix = input.current.x;
        let iy = input.current.y;
        if (keys.has("w") || keys.has("arrowup") || keys.has("ц")) iy += 1;
        if (keys.has("s") || keys.has("arrowdown") || keys.has("ы")) iy -= 1;
        if (keys.has("a") || keys.has("arrowleft") || keys.has("ф")) ix -= 1;
        if (keys.has("d") || keys.has("arrowright") || keys.has("в")) ix += 1;
        const len = Math.hypot(ix, iy);
        if (len > 1) {
          ix /= len;
          iy /= len;
        }
        const wantJump = input.current.jump || keys.has(" ");

        fwd.set(-Math.sin(yaw), 0, -Math.cos(yaw));
        right.set(Math.cos(yaw), 0, -Math.sin(yaw));
        dir.copy(fwd).multiplyScalar(iy).addScaledVector(right, ix);
        moving = len > 0.05;
        if (moving) ry = Math.atan2(dir.x, dir.z);

        // ---- physics
        prev.copy(pos);
        if (wantJump && grounded) {
          vy = JUMP_POWER;
          grounded = false;
        }
        vy -= GRAVITY * dt;
        pos.y += vy * dt;
        pos.x += dir.x * WALK_SPEED * dt;
        pos.z += dir.z * WALK_SPEED * dt;

        // horizontal / ceiling collisions with three stacked spheres
        push.set(0, 0, 0);
        for (const h of [2.0, 3.2, 4.4]) {
          sphere.set(pos.x, pos.y + h, pos.z);
          rbx.resolveSphere(built.colliders, sphere, 1.0, push);
          pos.x = sphere.x;
          pos.z = sphere.z;
          pos.y = sphere.y - h;
        }
        if (push.y < -0.001 && vy > 0) vy = 0;

        // ground snap via raycast from where we were
        grounded = false;
        if (vy <= 0) {
          const drop = Math.max(0, prev.y - pos.y);
          raycaster.set(proj.set(pos.x, prev.y + 1.1, pos.z), DOWN);
          raycaster.far = 1.1 + drop + 0.25;
          const hits = raycaster.intersectObjects(built.raycastTargets, false);
          if (hits.length) {
            const h = hits[0].point.y;
            if (h <= prev.y + 1.1 && h >= pos.y - 0.3) {
              pos.y = h;
              vy = 0;
              grounded = true;
            }
          }
        }
        if (pos.y < -120) respawn();

        rig.group.position.copy(pos);
        rig.group.rotation.y = ry;
        rbx.animateCharacter(rig, dt, moving, !grounded);

        // ---- remotes
        for (const r of remotes.values()) {
          const k = 1 - Math.exp(-dt * 12);
          r.rig.group.position.lerp(r.target, k);
          let d = r.ry - r.rig.group.rotation.y;
          d = Math.atan2(Math.sin(d), Math.cos(d));
          r.rig.group.rotation.y += d * k;
          rbx.animateCharacter(r.rig, dt, r.moving, r.airborne);
        }

        // ---- network send (15 Hz)
        if (socket.connected && now - lastSend > 66) {
          lastSend = now;
          socket.volatile.emit("state", {
            p: [+pos.x.toFixed(2), +pos.y.toFixed(2), +pos.z.toFixed(2)],
            r: +ry.toFixed(3),
            m: moving ? 1 : 0,
            a: grounded ? 0 : 1,
          });
        }

        hostStep(dt, now);
        rbx.updateEmitters(built, dt);

        // ---- camera
        camTarget.set(pos.x, pos.y + 4.5, pos.z);
        camera.position.set(
          camTarget.x + dist * Math.sin(yaw) * Math.cos(pitch),
          camTarget.y + dist * Math.sin(pitch),
          camTarget.z + dist * Math.cos(yaw) * Math.cos(pitch),
        );
        camera.lookAt(camTarget);

        // ---- overlays
        const w = mount.clientWidth, hgt = mount.clientHeight;
        const place = (tag: HTMLDivElement, p: Vector3) => {
          proj.set(p.x, p.y + 6.1, p.z).project(camera);
          if (proj.z > 1 || proj.z < -1) {
            tag.style.display = "none";
            return;
          }
          tag.style.display = "flex";
          tag.style.left = `${((proj.x + 1) / 2) * w}px`;
          tag.style.top = `${((1 - proj.y) / 2) * hgt}px`;
        };
        for (const r of remotes.values()) {
          place(r.tag, r.rig.group.position);
          if (r.bubbleUntil && now > r.bubbleUntil) {
            r.bubble.style.display = "none";
            r.bubbleUntil = 0;
          }
        }
        if (selfBubbleUntil && now > selfBubbleUntil) {
          selfTag.bubble.style.display = "none";
          selfBubbleUntil = 0;
        }
        if (selfBubbleUntil) place(selfTag.wrap, pos);
        else selfTag.wrap.style.display = "none";

        renderer.render(scene, camera);
      };
      step();

      leaveRef.current = () => {
        socket.emit("leave");
      };

      cleanup = () => {
        cancelAnimationFrame(raf);
        clearInterval(beatTimer);
        clearTimeout(readyTimer);
        socket.emit("leave");
        socket.disconnect();
        socketRef.current = null;
        window.removeEventListener("keydown", kd);
        window.removeEventListener("keyup", ku);
        window.removeEventListener("resize", resize);
        el.removeEventListener("pointerdown", pd);
        el.removeEventListener("pointermove", pm);
        el.removeEventListener("pointerup", pu);
        el.removeEventListener("pointercancel", pu);
        el.removeEventListener("wheel", wheel);
        renderer.dispose();
        mount.innerHTML = "";
        overlay.innerHTML = "";
        fetch("/api/presence", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ status: "online" }),
          keepalive: true,
        }).catch(() => {});
      };
    })().catch((e) => setError(e instanceof Error ? e.message : "Failed to start the game"));

    return () => {
      disposed = true;
      cleanup?.();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [meta]);

  /* ---------------- joystick ---------------- */
  useEffect(() => {
    const joy = joyRef.current;
    const knob = knobRef.current;
    if (!joy || !knob) return;
    let pid: number | null = null;
    const R = 44;
    const setKnob = (x: number, y: number) => {
      knob.style.transform = `translate(${x}px, ${y}px)`;
    };
    const handle = (e: PointerEvent) => {
      const rect = joy.getBoundingClientRect();
      let dx = e.clientX - (rect.left + rect.width / 2);
      let dy = e.clientY - (rect.top + rect.height / 2);
      const d = Math.hypot(dx, dy);
      if (d > R) {
        dx = (dx / d) * R;
        dy = (dy / d) * R;
      }
      setKnob(dx, dy);
      input.current.x = dx / R;
      input.current.y = -dy / R;
    };
    const down = (e: PointerEvent) => {
      if (pid !== null) return;
      pid = e.pointerId;
      joy.setPointerCapture(e.pointerId);
      handle(e);
    };
    const move = (e: PointerEvent) => {
      if (e.pointerId === pid) handle(e);
    };
    const up = (e: PointerEvent) => {
      if (e.pointerId !== pid) return;
      pid = null;
      setKnob(0, 0);
      input.current.x = 0;
      input.current.y = 0;
    };
    joy.addEventListener("pointerdown", down);
    joy.addEventListener("pointermove", move);
    joy.addEventListener("pointerup", up);
    joy.addEventListener("pointercancel", up);
    return () => {
      joy.removeEventListener("pointerdown", down);
      joy.removeEventListener("pointermove", move);
      joy.removeEventListener("pointerup", up);
      joy.removeEventListener("pointercancel", up);
    };
  }, [isTouch, ready]);

  const sendChat = () => {
    const v = chatText.trim();
    if (!v || !socketRef.current) return;
    socketRef.current.emit("chat", v);
    setChatText("");
  };

  const leave = () => {
    leaveRef.current();
    router.push(`/games/${placeId}`);
  };

  const openMenu = async () => {
    setMenuOpen(true);
    const j = await fetch("/api/friends").then((r) => r.json());
    const map: Record<number, string> = {};
    for (const f of j.friends ?? []) map[f.id] = "friends";
    for (const f of j.outgoing ?? []) map[f.id] = "outgoing";
    for (const f of j.incoming ?? []) map[f.id] = "incoming";
    setFriendState(map);
  };
  const addFriend = async (userId: number) => {
    const j = await fetch("/api/friends", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: friendState[userId] === "incoming" ? "accept" : "add", userId }),
    }).then((r) => r.json());
    setFriendState((s) => ({ ...s, [userId]: j.status ?? "outgoing" }));
  };

  const hostName = players.find((p) => p.id === hostId)?.username;

  return (
    <div className="fixed inset-0 select-none overflow-hidden bg-black text-white">
      <div ref={mountRef} className="absolute inset-0 touch-none" />
      <div ref={overlayRef} className="pointer-events-none absolute inset-0 overflow-hidden" />

      {/* top-left controls */}
      <div className="absolute left-2 top-2 flex items-center gap-2">
        <button onClick={openMenu} className="flex h-10 w-10 items-center justify-center rounded bg-black/50" aria-label="menu">
          <BurgerIcon size={24} />
        </button>
        <button onClick={() => setChatOpen((v) => !v)} className="flex h-10 w-10 items-center justify-center rounded bg-black/50" aria-label="chat">
          <ChatIcon size={22} />
        </button>
      </div>
      <div className="absolute right-2 top-2 rounded bg-black/40 px-2 py-1 text-xs">
        {players.length} online{hostName ? ` · host: ${hostName}` : ""}
      </div>

      {/* chat panel */}
      {chatOpen && (
        <div className="absolute left-2 top-14 flex w-[min(92vw,340px)] flex-col rounded bg-black/55 p-2">
          <div className="max-h-40 space-y-0.5 overflow-y-auto text-sm">
            {chatLog.map((m, i) => (
              <div key={i}>
                <span className="font-semibold text-[#9fd3ff]">{m.username}: </span>
                <span>{m.text}</span>
              </div>
            ))}
          </div>
          <form
            className="mt-2 flex gap-1"
            onSubmit={(e) => {
              e.preventDefault();
              sendChat();
            }}
          >
            <input
              className="flex-1 rounded bg-white/90 px-2 py-1 text-sm text-black outline-none"
              placeholder="To chat click here or press / key"
              value={chatText}
              maxLength={200}
              onChange={(e) => setChatText(e.target.value)}
            />
            <button className="rounded bg-[#3aa6e0] px-3 text-sm font-semibold">Send</button>
          </form>
        </div>
      )}

      {/* touch controls */}
      {isTouch && (
        <>
          <div ref={joyRef} className="absolute bottom-6 left-6 h-32 w-32 touch-none rounded-full border-2 border-white/40 bg-white/10">
            <div ref={knobRef} className="absolute left-1/2 top-1/2 -ml-7 -mt-7 h-14 w-14 rounded-full bg-white/60" />
          </div>
          <button
            className="absolute bottom-8 right-8 flex h-20 w-20 touch-none items-center justify-center rounded-full border-2 border-white/40 bg-white/15 active:bg-white/40"
            onPointerDown={(e) => {
              e.preventDefault();
              input.current.jump = true;
            }}
            onPointerUp={() => (input.current.jump = false)}
            onPointerCancel={() => (input.current.jump = false)}
            onPointerLeave={() => (input.current.jump = false)}
            aria-label="jump"
          >
            <JumpIcon size={36} />
          </button>
        </>
      )}

      {/* burger menu */}
      {menuOpen && (
        <div className="absolute inset-0 z-20 flex items-start justify-center bg-black/60 p-4 pt-10">
          <div className="w-full max-w-md rounded bg-[#1d1d1d] text-white shadow-xl">
            <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
              <div>
                <div className="text-base font-bold">{meta?.name}</div>
                <div className="text-xs text-white/60">
                  Listen server · host: {hostName ?? "…"} {hostId === selfId ? "(you)" : ""}
                </div>
              </div>
              <button onClick={() => setMenuOpen(false)} aria-label="close">
                <CloseIcon size={22} />
              </button>
            </div>
            <div className="max-h-[50vh] overflow-y-auto">
              {players.map((p) => (
                <div key={p.id} className="flex items-center gap-3 border-b border-white/5 px-4 py-2">
                  <div className="flex-1 text-sm">
                    {p.username}
                    {p.id === hostId && <span className="ml-2 rounded bg-[#2a9d4b] px-1.5 text-[10px] font-bold">HOST</span>}
                    {p.id === selfId && <span className="ml-2 text-xs text-white/50">(you)</span>}
                  </div>
                  {p.userId !== me.id && (
                    <button
                      onClick={() => addFriend(p.userId)}
                      disabled={friendState[p.userId] === "friends" || friendState[p.userId] === "outgoing"}
                      className="flex items-center gap-1 rounded border border-white/30 px-2 py-1 text-xs disabled:opacity-50"
                    >
                      <AddPersonIcon size={16} />
                      {friendState[p.userId] === "friends"
                        ? "Friends"
                        : friendState[p.userId] === "outgoing"
                          ? "Requested"
                          : friendState[p.userId] === "incoming"
                            ? "Accept"
                            : "Add Friend"}
                    </button>
                  )}
                </div>
              ))}
            </div>
            <div className="flex gap-2 p-4">
              <button onClick={() => setMenuOpen(false)} className="flex-1 rounded border border-white/30 py-2 text-sm font-semibold">
                Resume
              </button>
              <button onClick={leave} className="flex-1 rounded bg-[#d0342c] py-2 text-sm font-semibold">
                Leave Game
              </button>
            </div>
          </div>
        </div>
      )}

      {/* loading screen */}
      {(!ready || !meta) && (
        <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-[#1b1b1b]">
          {error ? (
            <div className="text-center">
              <p className="text-red-400">{error}</p>
              <button onClick={() => router.push("/games")} className="mt-4 rounded border border-white/30 px-4 py-2 text-sm">
                Back
              </button>
            </div>
          ) : (
            <>
              <div className="h-40 w-72 overflow-hidden rounded bg-[#333]">
                {meta?.thumbnail ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={meta.thumbnail} alt="" className="h-full w-full object-cover" />
                ) : (
                  <div className="h-full w-full bg-gradient-to-br from-[#8fbf6b] to-[#4c8a3f]" />
                )}
              </div>
              <div className="mt-4 text-xl font-bold">{meta?.name ?? "…"}</div>
              <div className="text-sm text-white/70">By {meta?.ownerName ?? "…"}</div>
            </>
          )}
          <RobloxMark size={36} className="rbx-spin absolute bottom-6 right-6 text-white/80" />
        </div>
      )}
    </div>
  );
}
