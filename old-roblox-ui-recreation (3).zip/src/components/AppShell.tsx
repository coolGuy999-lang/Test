"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { AvatarData } from "@/db/schema";
import { tr, type Lang, type TKey } from "@/lib/i18n";
import {
  ChatIcon,
  ChevronLeft,
  CloseIcon,
  FullscreenIcon,
  GamepadIcon,
  HomeIcon,
  MoreIcon,
  PersonIcon,
  RobuxIcon,
  SearchIcon,
} from "./Icons";

export type Me = {
  id: number;
  username: string;
  gender: string;
  avatar: AvatarData;
  description: string;
  robux: number;
  language: string;
};

type AppCtx = {
  me: Me;
  setMe: (patch: Partial<Me>) => void;
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (k: TKey) => string;
};

const Ctx = createContext<AppCtx | null>(null);
export function useApp() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useApp outside AppShell");
  return c;
}

export const TABS = [
  { key: "home", href: "/home", color: "#1e78c8", Icon: HomeIcon },
  { key: "games", href: "/games", color: "#2a9d4b", Icon: GamepadIcon },
  { key: "avatar", href: "/avatar", color: "#f0862d", Icon: PersonIcon },
  { key: "chat", href: "/chat", color: "#3aa6e0", Icon: ChatIcon },
  { key: "more", href: "/more", color: "#5b6270", Icon: MoreIcon },
] as const;

function tabFor(path: string) {
  if (path.startsWith("/games") || path.startsWith("/search")) return TABS[1];
  if (path.startsWith("/avatar")) return TABS[2];
  if (path.startsWith("/chat")) return TABS[3];
  if (path.startsWith("/more") || path.startsWith("/create")) return TABS[4];
  return TABS[0];
}

export default function AppShell({ initialMe, children }: { initialMe: Me; children: ReactNode }) {
  const [me, setMeState] = useState<Me>(initialMe);
  const [lang, setLangState] = useState<Lang>(initialMe.language === "ru" ? "ru" : "en");
  const [toast, setToast] = useState<string | null>(null);
  const [fsBanner, setFsBanner] = useState(false);
  const pathname = usePathname() ?? "/home";
  const router = useRouter();

  const t = useCallback((k: TKey) => tr(lang, k), [lang]);
  const setMe = useCallback((patch: Partial<Me>) => setMeState((m) => ({ ...m, ...patch })), []);
  const setLang = useCallback(
    (l: Lang) => {
      setLangState(l);
      setMeState((m) => ({ ...m, language: l }));
      fetch("/api/users", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "language", language: l }) });
    },
    [],
  );

  // Presence heartbeat + daily robux
  useEffect(() => {
    let alive = true;
    const beat = async () => {
      try {
        const r = await fetch("/api/presence", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ status: "online" }),
        });
        const j = await r.json();
        if (!alive) return;
        if (typeof j.robux === "number") setMeState((m) => ({ ...m, robux: j.robux }));
        if (j.claimed) {
          setToast(tr(lang, "robuxDaily"));
          setTimeout(() => setToast(null), 5000);
        }
      } catch {}
    };
    beat();
    const id = setInterval(beat, 30000);
    return () => {
      alive = false;
      clearInterval(id);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const dismissed = sessionStorage.getItem("rbx_fs_dismissed");
    const isMobile = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent) || window.innerWidth < 900;
    if (!dismissed && isMobile && !document.fullscreenElement) setFsBanner(true);
  }, []);

  const goFullscreen = async () => {
    try {
      await document.documentElement.requestFullscreen?.();
      const o = screen.orientation as ScreenOrientation & { lock?: (o: string) => Promise<void> };
      await o.lock?.("landscape").catch(() => {});
    } catch {}
    setFsBanner(false);
    sessionStorage.setItem("rbx_fs_dismissed", "1");
  };

  const tab = tabFor(pathname);
  const isRoot = TABS.some((tb) => tb.href === pathname);
  const title = useMemo(() => {
    if (pathname.startsWith("/users/")) return me.username;
    if (pathname.startsWith("/search")) return t("search");
    if (pathname.startsWith("/create")) return t("create");
    if (pathname.startsWith("/friends")) return t("friends");
    if (pathname.startsWith("/games/")) return t("games");
    if (pathname.startsWith("/chat/")) return t("chat");
    return t(tab.key as TKey);
  }, [pathname, tab.key, t, me.username]);

  const ctx: AppCtx = { me, setMe, lang, setLang, t };

  return (
    <Ctx.Provider value={ctx}>
      <div className="flex min-h-screen flex-col bg-white text-[#191919]">
        {fsBanner && (
          <div className="flex items-center gap-3 bg-[#f2f4f5] px-3 py-2 text-sm text-[#333]">
            <FullscreenIcon size={20} className="text-[#1e78c8]" />
            <span className="flex-1">{t("fullscreenHint")}</span>
            <button onClick={goFullscreen} className="rounded border border-[#1e78c8] px-3 py-1 text-xs font-semibold text-[#1e78c8]">
              {t("goFullscreen")}
            </button>
            <button
              aria-label="close"
              onClick={() => {
                setFsBanner(false);
                sessionStorage.setItem("rbx_fs_dismissed", "1");
              }}
              className="text-[#666]"
            >
              <CloseIcon size={18} />
            </button>
          </div>
        )}
        <header
          className="sticky top-0 z-30 flex h-14 items-center px-2 text-white shadow"
          style={{ backgroundColor: tab.color }}
        >
          <div className="w-20">
            {!isRoot && (
              <button onClick={() => router.back()} className="flex h-10 w-10 items-center justify-center" aria-label="back">
                <ChevronLeft size={26} />
              </button>
            )}
          </div>
          <h1 className="flex-1 truncate text-center text-lg font-semibold tracking-wide">{title}</h1>
          <div className="flex w-20 items-center justify-end gap-1">
            <Link href="/search" className="flex h-10 w-10 items-center justify-center" aria-label="search">
              <SearchIcon size={22} />
            </Link>
            <div className="flex h-10 items-center gap-1 pr-1" title="Robux">
              <RobuxIcon size={22} />
              <span className="text-sm font-semibold">{me.robux}</span>
            </div>
          </div>
        </header>

        <main className="flex-1 pb-20">{children}</main>

        {toast && (
          <div className="fixed left-1/2 top-16 z-50 -translate-x-1/2 rounded bg-[#2a9d4b] px-4 py-2 text-sm font-semibold text-white shadow-lg">
            {toast}
          </div>
        )}

        <nav className="fixed inset-x-0 bottom-0 z-30 flex h-16 border-t border-[#e3e3e3] bg-white">
          {TABS.map(({ key, href, color, Icon }) => {
            const active = tab.key === key;
            return (
              <Link
                key={key}
                href={href}
                className="flex flex-1 flex-col items-center justify-center gap-0.5 text-[10px] font-semibold uppercase tracking-wide"
                style={{ color: active ? color : "#8f8f8f" }}
              >
                <Icon size={26} />
                {t(key as TKey)}
              </Link>
            );
          })}
        </nav>
      </div>
    </Ctx.Provider>
  );
}

export const inputCls =
  "w-full rounded border border-[#d5d5d5] bg-white px-3 py-2 text-sm outline-none focus:border-[#1e78c8]";
export const greenBtn =
  "rounded bg-[#5fbf72] px-4 py-2 text-sm font-semibold text-white hover:bg-[#4fae62] disabled:opacity-60";
export const outlineBtn =
  "rounded border border-[#d5d5d5] bg-white px-4 py-2 text-sm font-semibold text-[#333] hover:bg-[#f5f5f5] disabled:opacity-60";
