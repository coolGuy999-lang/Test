"use client";
import { useEffect, useRef, useState } from "react";
import type { AvatarData } from "@/db/schema";

type Props = {
  avatar: AvatarData;
  mode?: "bust" | "full";
  size?: number;
  className?: string;
  live?: boolean;
};

/**
 * Renders the R6 avatar. Non-live mode uses a shared offscreen WebGL renderer and
 * caches a PNG so lists of friends don't exhaust WebGL contexts. Live mode mounts a
 * real canvas that can be rotated by dragging (used in the avatar editor).
 */
export default function AvatarView({ avatar, mode = "bust", size = 96, className = "", live = false }: Props) {
  const [src, setSrc] = useState<string | null>(null);
  const key = JSON.stringify(avatar) + mode;

  useEffect(() => {
    if (live) return;
    let cancelled = false;
    import("@/lib/three-rbx").then(({ renderAvatarThumb }) => {
      if (cancelled) return;
      try {
        setSrc(renderAvatarThumb(avatar, mode, mode === "bust" ? 256 : 384));
      } catch {
        setSrc(null);
      }
    });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, live]);

  if (live) return <LiveAvatar avatar={avatar} className={className} />;

  return (
    <div
      className={`overflow-hidden bg-[#f2f2f2] ${className}`}
      style={{ width: size, height: size }}
    >
      {src ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={src} alt="" width={size} height={size} className="block h-full w-full object-cover" draggable={false} />
      ) : null}
    </div>
  );
}

function LiveAvatar({ avatar, className }: { avatar: AvatarData; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const avatarRef = useRef(avatar);
  avatarRef.current = avatar;

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let stop = false;
    let cleanup: (() => void) | null = null;
    Promise.all([import("three"), import("@/lib/three-rbx")]).then(([THREE, rbx]) => {
      if (stop || !el) return;
      const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      renderer.setSize(el.clientWidth, el.clientHeight);
      el.appendChild(renderer.domElement);
      const scene = new THREE.Scene();
      scene.add(new THREE.AmbientLight(0xffffff, 1.5));
      const dir = new THREE.DirectionalLight(0xffffff, 1.7);
      dir.position.set(3, 8, 6);
      scene.add(dir);
      const cam = new THREE.PerspectiveCamera(32, el.clientWidth / el.clientHeight, 0.1, 100);
      cam.position.set(0, 3.6, 13.5);
      cam.lookAt(0, 2.7, 0);
      let rig = rbx.buildCharacter(avatarRef.current);
      scene.add(rig.group);
      let currentKey = JSON.stringify(avatarRef.current);
      let yaw = -0.4;
      let dragging = false;
      let lastX = 0;
      let raf = 0;
      const onDown = (e: PointerEvent) => {
        dragging = true;
        lastX = e.clientX;
      };
      const onMove = (e: PointerEvent) => {
        if (!dragging) return;
        yaw += (e.clientX - lastX) * 0.01;
        lastX = e.clientX;
      };
      const onUp = () => (dragging = false);
      renderer.domElement.addEventListener("pointerdown", onDown);
      window.addEventListener("pointermove", onMove);
      window.addEventListener("pointerup", onUp);
      const resize = () => {
        renderer.setSize(el.clientWidth, el.clientHeight);
        cam.aspect = el.clientWidth / el.clientHeight;
        cam.updateProjectionMatrix();
      };
      window.addEventListener("resize", resize);
      const loop = () => {
        raf = requestAnimationFrame(loop);
        const k = JSON.stringify(avatarRef.current);
        if (k !== currentKey) {
          scene.remove(rig.group);
          rig = rbx.buildCharacter(avatarRef.current);
          scene.add(rig.group);
          currentKey = k;
        }
        if (!dragging) yaw += 0.004;
        rig.group.rotation.y = yaw;
        renderer.render(scene, cam);
      };
      loop();
      cleanup = () => {
        cancelAnimationFrame(raf);
        renderer.domElement.removeEventListener("pointerdown", onDown);
        window.removeEventListener("pointermove", onMove);
        window.removeEventListener("pointerup", onUp);
        window.removeEventListener("resize", resize);
        renderer.dispose();
        el.innerHTML = "";
      };
    });
    return () => {
      stop = true;
      cleanup?.();
    };
  }, []);

  return <div ref={ref} className={`touch-none ${className ?? ""}`} />;
}
