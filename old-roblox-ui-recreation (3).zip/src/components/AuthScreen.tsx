"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { ChevronDown, FemaleFigure, MaleFigure, RobloxMark } from "./Icons";

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const box = "rounded border border-[#d9d9d9] bg-white";
const field = `${box} w-full px-3 py-2.5 text-sm text-[#333] placeholder-[#9a9a9a] outline-none focus:border-[#b5b5b5]`;

export function RobloxLogo({ className = "" }: { className?: string }) {
  return (
    <div className={`select-none text-center ${className}`}>
      <span
        className="inline-block text-[52px] font-black uppercase leading-none tracking-tight text-[#e2231a]"
        style={{ fontFamily: "'Passion One', 'Arial Black', Impact, sans-serif", transform: "skewX(-6deg)", textShadow: "2px 2px 0 #7a0f0a" }}
      >
        Roblox
      </span>
    </div>
  );
}

export default function AuthScreen() {
  const router = useRouter();
  const [mode, setMode] = useState<"none" | "login" | "signup">("none");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [login, setLogin] = useState({ username: "", password: "" });
  const [su, setSu] = useState({
    month: "",
    day: "",
    year: "",
    username: "",
    password: "",
    confirm: "",
    gender: "" as "" | "female" | "male",
  });

  const submit = async (action: "login" | "signup") => {
    setBusy(true);
    setError(null);
    try {
      const r = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(action === "login" ? { action, ...login } : { action, ...su }),
      });
      const j = await r.json();
      if (!r.ok) {
        setError(j.error ?? "Something went wrong");
        setBusy(false);
        return;
      }
      // brief loading moment like the old app
      await new Promise((res) => setTimeout(res, 900));
      router.replace("/home");
      router.refresh();
    } catch {
      setError("Network error");
      setBusy(false);
    }
  };

  return (
    <div className="flex min-h-screen flex-col items-center bg-white px-6 pb-10 pt-14 text-[#333]">
      <RobloxLogo />

      <div className="mt-8 flex w-full max-w-xs gap-3">
        <button
          className={`${box} flex-1 py-2.5 text-sm font-semibold ${mode === "login" ? "border-[#a8a8a8]" : ""}`}
          onClick={() => {
            setMode(mode === "login" ? "none" : "login");
            setError(null);
          }}
        >
          Login
        </button>
        <button
          className={`${box} flex-1 py-2.5 text-sm font-semibold ${mode === "signup" ? "border-[#a8a8a8]" : ""}`}
          onClick={() => {
            setMode(mode === "signup" ? "none" : "signup");
            setError(null);
          }}
        >
          Sign Up
        </button>
      </div>

      {mode === "login" && (
        <form
          className="mt-6 flex w-full max-w-xs flex-col gap-3"
          onSubmit={(e) => {
            e.preventDefault();
            submit("login");
          }}
        >
          <input
            className={field}
            placeholder="Username"
            autoComplete="username"
            value={login.username}
            onChange={(e) => setLogin({ ...login, username: e.target.value })}
          />
          <input
            className={field}
            type="password"
            placeholder="Password"
            autoComplete="current-password"
            value={login.password}
            onChange={(e) => setLogin({ ...login, password: e.target.value })}
          />
          <button disabled={busy} className="mt-1 rounded bg-[#8fce9c] py-2.5 text-sm font-semibold text-white disabled:opacity-70">
            {busy ? <Spinner /> : "Login"}
          </button>
        </form>
      )}

      {mode === "signup" && (
        <form
          className="mt-6 flex w-full max-w-xs flex-col gap-3"
          onSubmit={(e) => {
            e.preventDefault();
            submit("signup");
          }}
        >
          <div className="flex items-stretch gap-2">
            <div className={`${box} flex items-center px-3 text-sm text-[#555]`}>Birthday</div>
            <Select value={su.month} onChange={(v) => setSu({ ...su, month: v })} placeholder="Month">
              {MONTHS.map((m, i) => (
                <option key={m} value={i + 1}>
                  {m}
                </option>
              ))}
            </Select>
            <Select value={su.day} onChange={(v) => setSu({ ...su, day: v })} placeholder="Day">
              {Array.from({ length: 31 }, (_, i) => (
                <option key={i + 1} value={i + 1}>
                  {i + 1}
                </option>
              ))}
            </Select>
            <input
              className={`${box} w-[4.6rem] px-2 py-2 text-sm text-[#333] placeholder-[#9a9a9a] outline-none`}
              placeholder="Year"
              inputMode="numeric"
              maxLength={4}
              value={su.year}
              onChange={(e) => setSu({ ...su, year: e.target.value.replace(/\D/g, "") })}
            />
          </div>
          <input
            className={field}
            placeholder="Username (don't use your real name)"
            autoComplete="off"
            value={su.username}
            onChange={(e) => setSu({ ...su, username: e.target.value })}
          />
          <input
            className={field}
            type="password"
            placeholder="Password (minimum length 8)"
            autoComplete="new-password"
            value={su.password}
            onChange={(e) => setSu({ ...su, password: e.target.value })}
          />
          <input
            className={field}
            type="password"
            placeholder="Confirm Password"
            autoComplete="new-password"
            value={su.confirm}
            onChange={(e) => setSu({ ...su, confirm: e.target.value })}
          />
          <div className="flex items-center gap-3">
            <div className={`${box} px-3 py-2 text-sm text-[#555]`}>Gender</div>
            <button
              type="button"
              aria-label="female"
              onClick={() => setSu({ ...su, gender: "female" })}
              className={`${box} flex h-12 w-12 items-center justify-center`}
              style={{ color: su.gender === "female" ? "#f27fb6" : "#a9a9a9" }}
            >
              <FemaleFigure size={34} />
            </button>
            <button
              type="button"
              aria-label="male"
              onClick={() => setSu({ ...su, gender: "male" })}
              className={`${box} flex h-12 w-12 items-center justify-center`}
              style={{ color: su.gender === "male" ? "#7cb9e8" : "#a9a9a9" }}
            >
              <MaleFigure size={34} />
            </button>
          </div>
          <button disabled={busy} className="mt-1 rounded bg-[#8fce9c] py-2.5 text-sm font-semibold text-white disabled:opacity-70">
            {busy ? <Spinner /> : "Sign Up"}
          </button>
        </form>
      )}

      {error && <p className="mt-4 max-w-xs text-center text-sm text-[#d0342c]">{error}</p>}

      <p className="mt-auto pt-10 text-xs text-[#aaa]">2018 - Listen server multiplayer with Socket.io relay</p>
    </div>
  );
}

function Select({
  value,
  onChange,
  placeholder,
  children,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  children: React.ReactNode;
}) {
  return (
    <div className={`${box} relative flex-1`}>
      <select
        className="h-full w-full appearance-none bg-transparent py-2 pl-2 pr-6 text-sm text-[#333] outline-none"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      >
        <option value="">{placeholder}</option>
        {children}
      </select>
      <ChevronDown size={16} className="pointer-events-none absolute right-1.5 top-1/2 -translate-y-1/2 text-[#666]" />
    </div>
  );
}

export function Spinner({ className = "" }: { className?: string }) {
  return (
    <span className={`inline-flex items-center justify-center ${className}`}>
      <RobloxMark size={20} className="animate-spin" />
    </span>
  );
}
