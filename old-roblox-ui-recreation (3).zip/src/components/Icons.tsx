import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement> & { size?: number };
const base = (size = 24) => ({ width: size, height: size, viewBox: "0 0 24 24", fill: "currentColor" as const });

export const HomeIcon = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="M12 3 2 12h3v8h5v-6h4v6h5v-8h3L12 3z" />
  </svg>
);
export const GamepadIcon = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="M7 6h10a5 5 0 0 1 5 5v2.5A3.5 3.5 0 0 1 18.5 17c-1.3 0-2.4-.7-3-1.7L15 14H9l-.5 1.3c-.6 1-1.7 1.7-3 1.7A3.5 3.5 0 0 1 2 13.5V11a5 5 0 0 1 5-5zm-1 3v1.5H4.5v1.5H6V13.5h1.5V12H9v-1.5H7.5V9H6zm10 .5a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm2 2a1 1 0 1 0 0 2 1 1 0 0 0 0-2z" />
  </svg>
);
export const PersonIcon = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="M12 12a4.5 4.5 0 1 0 0-9 4.5 4.5 0 0 0 0 9zm0 2c-4 0-8 2-8 5v2h16v-2c0-3-4-5-8-5z" />
  </svg>
);
export const ChatIcon = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="M4 4h16a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H9l-5 4v-4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z" />
  </svg>
);
export const MoreIcon = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <circle cx="5" cy="12" r="2.2" />
    <circle cx="12" cy="12" r="2.2" />
    <circle cx="19" cy="12" r="2.2" />
  </svg>
);
export const SearchIcon = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p} fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round">
    <circle cx="10.5" cy="10.5" r="6.5" />
    <path d="m20 20-4.8-4.8" />
  </svg>
);
export const RobuxIcon = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="M11.2 2.4a1.6 1.6 0 0 1 1.6 0l7 4.05a1.6 1.6 0 0 1 .8 1.38v8.34a1.6 1.6 0 0 1-.8 1.38l-7 4.05a1.6 1.6 0 0 1-1.6 0l-7-4.05a1.6 1.6 0 0 1-.8-1.38V7.83a1.6 1.6 0 0 1 .8-1.38l7-4.05zM12 4.6 6 8.07v7.86l6 3.47 6-3.47V8.07l-6-3.47zm-2.4 4.2h4.8v6.4H9.6V8.8z" />
  </svg>
);
export const HammerIcon = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="M13.6 3.2 20.8 10.4l-2.1 2.1-1.4-1.4-1.4 1.4 1.4 1.4-8.5 8.5-2.8-2.8 8.5-8.5-2.9-2.9-1.4 1.4L8.1 7.5l3.4-3.4c.6-.6 1.5-.6 2.1 0v1.1z" />
  </svg>
);
export const AddPersonIcon = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="M9 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0 2c-3.6 0-7 1.8-7 4.5V20h14v-1.5C16 15.8 12.6 14 9 14zm10-6V5h-2v3h-3v2h3v3h2v-3h3V8h-3z" />
  </svg>
);
export const MessageIcon = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="M3 5h18a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1zm1 2.6V17h16V7.6l-8 5-8-5zM5.2 7l6.8 4.2L18.8 7H5.2z" />
  </svg>
);
export const BurgerIcon = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <rect x="3" y="5" width="18" height="2.6" rx="1" />
    <rect x="3" y="10.7" width="18" height="2.6" rx="1" />
    <rect x="3" y="16.4" width="18" height="2.6" rx="1" />
  </svg>
);
export const CloseIcon = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p} fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round">
    <path d="M6 6l12 12M18 6 6 18" />
  </svg>
);
export const FullscreenIcon = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p} fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5" />
  </svg>
);
export const ChevronDown = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p} fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round">
    <path d="m6 9 6 6 6-6" />
  </svg>
);
export const ChevronLeft = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p} fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round">
    <path d="m15 5-7 7 7 7" />
  </svg>
);
export const ThumbUpIcon = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="M2 10h4v11H2V10zm6 11V10l5-7c1.4 0 2.5 1.1 2.5 2.5V9H21a2 2 0 0 1 2 2.3l-1.2 7A2 2 0 0 1 19.8 20H8z" />
  </svg>
);
export const StarIcon = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="m12 2.5 2.9 6.1 6.6.8-4.9 4.6 1.3 6.6L12 17.3l-5.9 3.3 1.3-6.6L2.5 9.4l6.6-.8L12 2.5z" />
  </svg>
);
export const PlayIcon = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="M7 4.5v15l12-7.5-12-7.5z" />
  </svg>
);
export const UploadIcon = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p} fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 16V4m0 0-4 4m4-4 4 4M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3" />
  </svg>
);
export const JumpIcon = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p} fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 20V6m0 0-5 5m5-5 5 5" />
  </svg>
);
export const GearIcon = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p}>
    <path d="m19.4 13 .1-1-.1-1 2.1-1.6-2-3.5-2.5 1a7 7 0 0 0-1.7-1L15 3H9l-.4 2.7a7 7 0 0 0-1.7 1l-2.5-1-2 3.5L4.6 11l-.1 1 .1 1-2.1 1.6 2 3.5 2.5-1a7 7 0 0 0 1.7 1L9 21h6l.4-2.7a7 7 0 0 0 1.7-1l2.5 1 2-3.5L19.4 13zM12 15.5a3.5 3.5 0 1 1 0-7 3.5 3.5 0 0 1 0 7z" />
  </svg>
);
export const GlobeIcon = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p} fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round">
    <circle cx="12" cy="12" r="9" />
    <path d="M3 12h18M12 3c3 3.5 3 14.5 0 18M12 3c-3 3.5-3 14.5 0 18" />
  </svg>
);
export const LogoutIcon = ({ size, ...p }: P) => (
  <svg {...base(size)} {...p} fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round">
    <path d="M10 4H5a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h5M15 8l4 4-4 4M19 12H9" />
  </svg>
);

/* Gender figures for the sign up screen */
export const FemaleFigure = ({ size, ...p }: P) => (
  <svg width={size ?? 40} height={size ?? 40} viewBox="0 0 40 40" fill="currentColor" {...p}>
    <circle cx="20" cy="6" r="4.5" />
    <path d="M15.5 12h9l1 9h-3.2l2.6 10H15.1l2.6-10H14.5l1-9z" />
    <rect x="16" y="31" width="3" height="8" rx="1" />
    <rect x="21" y="31" width="3" height="8" rx="1" />
    <rect x="9.5" y="12.5" width="3" height="10" rx="1.5" transform="rotate(-20 11 17)" />
    <rect x="27.5" y="12.5" width="3" height="10" rx="1.5" transform="rotate(20 29 17)" />
  </svg>
);
export const MaleFigure = ({ size, ...p }: P) => (
  <svg width={size ?? 40} height={size ?? 40} viewBox="0 0 40 40" fill="currentColor" {...p}>
    <circle cx="20" cy="6" r="4.5" />
    <rect x="14" y="12" width="12" height="13" rx="2" />
    <rect x="14.5" y="25" width="4.8" height="14" rx="1.5" />
    <rect x="20.7" y="25" width="4.8" height="14" rx="1.5" />
    <rect x="9.5" y="12.5" width="3.5" height="12" rx="1.7" />
    <rect x="27" y="12.5" width="3.5" height="12" rx="1.7" />
  </svg>
);

/* Classic tilted-square Roblox mark used for spinners */
export const RobloxMark = ({ size, ...p }: P) => (
  <svg width={size ?? 40} height={size ?? 40} viewBox="0 0 40 40" fill="currentColor" {...p}>
    <path d="M9.6 2 38 9.6 30.4 38 2 30.4 9.6 2zm6.1 12.1-3.8 14.1 14.1 3.8 3.8-14.1-14.1-3.8z" />
  </svg>
);
