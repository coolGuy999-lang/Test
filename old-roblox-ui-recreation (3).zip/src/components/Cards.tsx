"use client";
import Link from "next/link";
import type { AvatarData } from "@/db/schema";
import AvatarView from "./AvatarView";
import { PersonIcon, ThumbUpIcon } from "./Icons";

export type PlaceSummary = {
  id: number;
  name: string;
  thumbnail: string | null;
  visits: number;
  ownerId: number;
  ownerName: string;
  likes: number;
  playing: number;
};

export type UserSummary = {
  id: number;
  username: string;
  avatar: AvatarData;
  presence: "online" | "ingame" | "offline" | string;
  currentPlaceId?: number | null;
};

export function PresenceDot({ presence, className = "" }: { presence: string; className?: string }) {
  if (presence === "offline") return null;
  const color = presence === "ingame" ? "#7ed957" : "#6fc3f7";
  return (
    <span
      className={`absolute h-3.5 w-3.5 rounded-full border-2 border-white ${className}`}
      style={{ backgroundColor: color }}
    />
  );
}

export function PlaceThumb({ place, className = "" }: { place: { name: string; thumbnail: string | null }; className?: string }) {
  return (
    <div className={`relative overflow-hidden rounded bg-[#e6e6e6] ${className}`} style={{ aspectRatio: "16 / 9" }}>
      {place.thumbnail ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={place.thumbnail} alt={place.name} className="h-full w-full object-cover" />
      ) : (
        <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-[#8fbf6b] to-[#4c8a3f]">
          <div className="grid grid-cols-4 gap-0.5 opacity-70">
            {Array.from({ length: 8 }).map((_, i) => (
              <span key={i} className="h-3 w-3 bg-[#635f62]" />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export function GameCard({ place }: { place: PlaceSummary }) {
  return (
    <Link href={`/games/${place.id}`} className="block">
      <PlaceThumb place={place} />
      <div className="mt-1 truncate text-sm font-semibold text-[#222]">{place.name}</div>
      <div className="flex items-center gap-2 text-xs text-[#777]">
        <span className="inline-flex items-center gap-0.5">
          <ThumbUpIcon size={12} /> {place.likes}
        </span>
        <span className="inline-flex items-center gap-0.5">
          <PersonIcon size={12} /> {place.playing}
        </span>
      </div>
    </Link>
  );
}

export function UserRow({ user, right }: { user: UserSummary; right?: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3 border-b border-[#eee] px-4 py-2">
      <Link href={`/users/${user.id}`} className="relative">
        <AvatarView avatar={user.avatar} size={48} className="rounded-full" />
        <PresenceDot presence={user.presence} className="bottom-0 right-0" />
      </Link>
      <Link href={`/users/${user.id}`} className="flex-1 truncate text-sm font-semibold text-[#222]">
        {user.username}
      </Link>
      {right}
    </div>
  );
}

export function FriendTile({ user }: { user: UserSummary }) {
  return (
    <Link href={`/users/${user.id}`} className="flex w-[74px] shrink-0 flex-col items-center gap-1">
      <div className="relative">
        <AvatarView avatar={user.avatar} size={64} className="rounded-full border border-[#e3e3e3]" />
        <PresenceDot presence={user.presence} className="bottom-0.5 right-0.5" />
      </div>
      <span className="w-full truncate text-center text-[11px] text-[#444]">{user.username}</span>
    </Link>
  );
}

export function SectionTitle({ children, action }: { children: React.ReactNode; action?: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between px-4 pb-2 pt-4">
      <h2 className="text-base font-bold text-[#222]">{children}</h2>
      {action}
    </div>
  );
}

export function fetchJson<T = Record<string, unknown>>(url: string, init?: RequestInit): Promise<T> {
  return fetch(url, init).then((r) => r.json());
}

export function post<T = Record<string, unknown>>(url: string, body: unknown): Promise<T> {
  return fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then(
    (r) => r.json(),
  );
}
