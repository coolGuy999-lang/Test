import type { NextApiRequest, NextApiResponse } from "next";
import type { Server as HTTPServer } from "http";
import type { Socket as NetSocket } from "net";
import { Server as IOServer, type Socket } from "socket.io";

export const config = { api: { bodyParser: false } };

type PlayerInfo = { id: string; userId: number; username: string; avatar: unknown };
type Room = { hostId: string | null; players: Map<string, PlayerInfo>; world: unknown };

type SocketServer = HTTPServer & { io?: IOServer };
type ResWithSocket = NextApiResponse & { socket: NetSocket & { server: SocketServer } };

const rooms = new Map<string, Room>();

function roomKey(placeId: number) {
  return `place:${placeId}`;
}

function leaveRoom(io: IOServer, socket: Socket) {
  const key = (socket.data.room as string | undefined) ?? null;
  if (!key) return;
  const room = rooms.get(key);
  socket.leave(key);
  socket.data.room = null;
  if (!room) return;
  room.players.delete(socket.id);
  io.to(key).emit("player_left", { id: socket.id });
  if (room.players.size === 0) {
    rooms.delete(key);
    return;
  }
  if (room.hostId === socket.id) {
    // Host migration: the longest-connected remaining player becomes the new listen server.
    const next = room.players.keys().next().value as string;
    room.hostId = next;
    io.to(key).emit("host", { hostId: next, world: room.world });
  }
}

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  const r = res as ResWithSocket;
  if (!r.socket.server.io) {
    const io = new IOServer(r.socket.server, {
      path: "/api/socketio",
      addTrailingSlash: false,
      cors: { origin: "*" },
      pingInterval: 10000,
      pingTimeout: 20000,
    });
    r.socket.server.io = io;

    io.on("connection", (socket) => {
      socket.on("join", (payload: { placeId: number; user: { id: number; username: string; avatar: unknown } }) => {
        if (!payload || !payload.placeId || !payload.user) return;
        leaveRoom(io, socket);
        const key = roomKey(Number(payload.placeId));
        let room = rooms.get(key);
        if (!room) {
          room = { hostId: null, players: new Map(), world: null };
          rooms.set(key, room);
        }
        const info: PlayerInfo = {
          id: socket.id,
          userId: payload.user.id,
          username: payload.user.username,
          avatar: payload.user.avatar,
        };
        room.players.set(socket.id, info);
        if (!room.hostId) room.hostId = socket.id;
        socket.data.room = key;
        socket.join(key);
        socket.emit("joined", {
          selfId: socket.id,
          hostId: room.hostId,
          players: [...room.players.values()],
          world: room.world,
        });
        socket.to(key).emit("player_joined", { player: info });
      });

      socket.on("state", (data: unknown) => {
        const key = socket.data.room as string | undefined;
        if (!key) return;
        socket.to(key).volatile.emit("state", { id: socket.id, ...(data as object) });
      });

      socket.on("chat", (text: unknown) => {
        const key = socket.data.room as string | undefined;
        if (!key) return;
        const room = rooms.get(key);
        const info = room?.players.get(socket.id);
        if (!info) return;
        const msg = String(text ?? "").trim().slice(0, 200);
        if (!msg) return;
        io.to(key).emit("chat", { id: socket.id, username: info.username, text: msg, ts: Date.now() });
      });

      // Listen-server authoritative world snapshot (only accepted from the current host).
      socket.on("world", (data: unknown) => {
        const key = socket.data.room as string | undefined;
        if (!key) return;
        const room = rooms.get(key);
        if (!room || room.hostId !== socket.id) return;
        room.world = data;
        socket.to(key).volatile.emit("world", data);
      });

      socket.on("leave", () => leaveRoom(io, socket));
      socket.on("disconnect", () => leaveRoom(io, socket));
    });
  }
  res.end();
}
