import { redirect } from "next/navigation";
import GameClient from "@/components/game/GameClient";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function PlayPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await getCurrentUser();
  if (!user) redirect("/");
  const placeId = Number(id);
  if (!placeId) redirect("/games");
  return <GameClient me={{ id: user.id, username: user.username, avatar: user.avatar }} placeId={placeId} />;
}
