"use client";
import { useState } from "react";
import type { AvatarData } from "@/db/schema";
import { greenBtn, useApp } from "@/components/AppShell";
import AvatarView from "@/components/AvatarView";
import { post } from "@/components/Cards";

const PALETTE = [
  "#f5cd30", "#f3cf9b", "#eab892", "#cc8e69", "#7c5c46", "#624732", "#f2f3f3", "#a3a2a5", "#635f62", "#1b2a35",
  "#c4281c", "#ff0000", "#da8541", "#f8d96d", "#4b974b", "#287f47", "#0d69ac", "#6e99ca", "#7bb6e8", "#04afec",
  "#e8a0bf", "#ff66cc", "#6b327c", "#8c5b9f", "#1c2b4a", "#1b7f3a", "#7b3fa0", "#ffffff",
];

type Part = "head" | "torso" | "leftArm" | "rightArm" | "leftLeg" | "rightLeg";
const PARTS: Part[] = ["head", "torso", "leftArm", "rightArm", "leftLeg", "rightLeg"];

export default function AvatarPage() {
  const { me, setMe, t } = useApp();
  const [avatar, setAvatar] = useState<AvatarData>(me.avatar);
  const [section, setSection] = useState<"body" | "clothing" | "hats">("body");
  const [part, setPart] = useState<Part>("torso");
  const [cloth, setCloth] = useState<"shirt" | "pants">("shirt");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const update = (patch: Partial<AvatarData>) => {
    setAvatar((a) => ({ ...a, ...patch }));
    setSaved(false);
  };
  const save = async () => {
    setSaving(true);
    const j = await post<{ avatar: AvatarData }>("/api/users", { action: "avatar", avatar });
    if (j.avatar) setMe({ avatar: j.avatar });
    setSaving(false);
    setSaved(true);
  };

  return (
    <div className="mx-auto flex max-w-3xl flex-col md:flex-row">
      <div className="relative h-[46vh] w-full bg-gradient-to-b from-[#dfeefc] to-white md:h-[70vh] md:w-1/2">
        <AvatarView avatar={avatar} live className="h-full w-full" />
        <button onClick={save} disabled={saving} className={`${greenBtn} absolute bottom-3 right-3`}>
          {saving ? "..." : saved ? t("saved") : t("save")}
        </button>
      </div>
      <div className="flex-1">
        <div className="flex border-b border-[#e3e3e3]">
          {(["body", "clothing", "hats"] as const).map((s) => (
            <button
              key={s}
              onClick={() => setSection(s)}
              className={`flex-1 py-2 text-sm font-semibold ${section === s ? "border-b-2 border-[#f0862d] text-[#f0862d]" : "text-[#666]"}`}
            >
              {s === "body" ? t("bodyColors") : s === "clothing" ? t("clothing") : t("hats")}
            </button>
          ))}
        </div>

        {section === "body" && (
          <div className="p-4">
            <div className="no-scrollbar flex gap-2 overflow-x-auto pb-3">
              {PARTS.map((p) => (
                <button
                  key={p}
                  onClick={() => setPart(p)}
                  className={`shrink-0 rounded-full border px-3 py-1 text-xs font-semibold ${part === p ? "border-[#f0862d] bg-[#f0862d] text-white" : "border-[#d5d5d5] text-[#444]"}`}
                >
                  {t(p)}
                </button>
              ))}
            </div>
            <Palette value={avatar[part]} onPick={(c) => update({ [part]: c } as Partial<AvatarData>)} />
          </div>
        )}

        {section === "clothing" && (
          <div className="p-4">
            <div className="flex gap-2 pb-3">
              {(["shirt", "pants"] as const).map((c) => (
                <button
                  key={c}
                  onClick={() => setCloth(c)}
                  className={`rounded-full border px-3 py-1 text-xs font-semibold ${cloth === c ? "border-[#f0862d] bg-[#f0862d] text-white" : "border-[#d5d5d5] text-[#444]"}`}
                >
                  {t(c)}
                </button>
              ))}
              <button onClick={() => update({ [cloth]: null } as Partial<AvatarData>)} className="ml-auto rounded-full border border-[#d5d5d5] px-3 py-1 text-xs font-semibold text-[#444]">
                {t("none")}
              </button>
            </div>
            <Palette value={avatar[cloth]} onPick={(c) => update({ [cloth]: c } as Partial<AvatarData>)} />
          </div>
        )}

        {section === "hats" && (
          <div className="grid grid-cols-2 gap-3 p-4">
            {(["none", "cap", "tophat", "visor"] as const).map((h) => (
              <button
                key={h}
                onClick={() => update({ hat: h })}
                className={`rounded border py-4 text-sm font-semibold ${avatar.hat === h ? "border-[#f0862d] text-[#f0862d]" : "border-[#d5d5d5] text-[#444]"}`}
              >
                {t(h)}
              </button>
            ))}
            <div className="col-span-2 mt-2 flex gap-2">
              {(["smile", "happy", "serious"] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => update({ face: f })}
                  className={`flex-1 rounded border py-2 text-xs font-semibold capitalize ${avatar.face === f ? "border-[#f0862d] text-[#f0862d]" : "border-[#d5d5d5] text-[#444]"}`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function Palette({ value, onPick }: { value: string | null; onPick: (c: string) => void }) {
  return (
    <div className="grid grid-cols-7 gap-2">
      {PALETTE.map((c) => (
        <button
          key={c}
          onClick={() => onPick(c)}
          className={`aspect-square rounded border-2 ${value === c ? "border-[#f0862d]" : "border-[#e3e3e3]"}`}
          style={{ backgroundColor: c }}
          aria-label={c}
        />
      ))}
    </div>
  );
}
