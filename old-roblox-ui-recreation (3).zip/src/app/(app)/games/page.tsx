"use client";
import { useEffect, useState } from "react";
import { useApp } from "@/components/AppShell";
import { fetchJson, GameCard, type PlaceSummary } from "@/components/Cards";

const SORTS = ["popular", "top", "favorites", "newest"] as const;

export default function GamesPage() {
  const { t } = useApp();
  const [sort, setSort] = useState<(typeof SORTS)[number]>("popular");
  const [places, setPlaces] = useState<PlaceSummary[] | null>(null);

  useEffect(() => {
    setPlaces(null);
    fetchJson<{ places: PlaceSummary[] }>(`/api/places?sort=${sort}`).then((j) => setPlaces(j.places ?? []));
  }, [sort]);

  const labels = { popular: t("popular"), top: t("topRated"), favorites: t("favorites"), newest: t("newest") };

  return (
    <div>
      <div className="no-scrollbar flex gap-2 overflow-x-auto border-b border-[#eee] px-4 py-3">
        {SORTS.map((s) => (
          <button
            key={s}
            onClick={() => setSort(s)}
            className={`shrink-0 rounded-full border px-4 py-1.5 text-sm font-semibold ${
              sort === s ? "border-[#2a9d4b] bg-[#2a9d4b] text-white" : "border-[#d5d5d5] text-[#444]"
            }`}
          >
            {labels[s]}
          </button>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-3 p-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
        {places && places.length === 0 && <p className="col-span-full text-sm text-[#777]">{t("nothingFound")}</p>}
        {places?.map((p) => (
          <GameCard key={p.id} place={p} />
        ))}
      </div>
    </div>
  );
}
