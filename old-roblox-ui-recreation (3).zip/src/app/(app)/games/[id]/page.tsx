"use client";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import { useApp } from "@/components/AppShell";
import { fetchJson, PlaceThumb, post } from "@/components/Cards";
import { PersonIcon, PlayIcon, StarIcon, ThumbUpIcon } from "@/components/Icons";

type Detail = {
  id: number;
  name: string;
  description: string;
  thumbnail: string | null;
  visits: number;
  ownerId: number;
  ownerName: string;
  createdAt: string;
  updatedAt: string;
  likes: number;
  playing: number;
  stats: { parts: number; models: number; scripts: number; particles: number; images: number } | null;
};

export default function GameDetailPage() {
  const id = useParams<{ id: string }>()?.id ?? "";
  const { t } = useApp();
  const [place, setPlace] = useState<Detail | null>(null);
  const [liked, setLiked] = useState(false);
  const [fav, setFav] = useState(false);

  useEffect(() => {
    fetchJson<{ place: Detail; liked: boolean; favorited: boolean }>(`/api/places/${id}`).then((j) => {
      setPlace(j.place);
      setLiked(j.liked);
      setFav(j.favorited);
    });
  }, [id]);

  if (!place) return <div className="p-6 text-center text-sm text-[#777]">{t("loading")}...</div>;

  const toggleLike = async () => {
    const j = await post<{ liked: boolean }>("/api/places", { action: "like", placeId: place.id });
    setLiked(j.liked);
    setPlace({ ...place, likes: place.likes + (j.liked ? 1 : -1) });
  };
  const toggleFav = async () => {
    const j = await post<{ favorited: boolean }>("/api/places", { action: "favorite", placeId: place.id });
    setFav(j.favorited);
  };

  return (
    <div className="mx-auto max-w-3xl">
      <div className="p-4">
        <PlaceThumb place={place} className="mx-auto max-w-xl" />
        <h1 className="mt-3 text-xl font-bold">{place.name}</h1>
        <p className="text-sm text-[#666]">
          {t("by")}{" "}
          <Link href={`/users/${place.ownerId}`} className="font-semibold text-[#1e78c8]">
            {place.ownerName}
          </Link>
        </p>
        <Link
          href={`/play/${place.id}`}
          className="mt-4 flex w-full items-center justify-center gap-2 rounded bg-[#2a9d4b] py-3 text-lg font-bold text-white hover:bg-[#248a41]"
        >
          <PlayIcon size={22} /> {t("play")}
        </Link>
        <div className="mt-3 flex items-center gap-2">
          <button
            onClick={toggleLike}
            className={`flex flex-1 items-center justify-center gap-2 rounded border py-2 text-sm font-semibold ${liked ? "border-[#2a9d4b] text-[#2a9d4b]" : "border-[#d5d5d5] text-[#444]"}`}
          >
            <ThumbUpIcon size={18} /> {t("like")} ({place.likes})
          </button>
          <button
            onClick={toggleFav}
            className={`flex flex-1 items-center justify-center gap-2 rounded border py-2 text-sm font-semibold ${fav ? "border-[#f0a500] text-[#f0a500]" : "border-[#d5d5d5] text-[#444]"}`}
          >
            <StarIcon size={18} /> {t("favorite")}
          </button>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-2 text-center">
          <Stat label={t("playing")} value={place.playing} icon={<PersonIcon size={14} />} />
          <Stat label={t("visits")} value={place.visits} />
          <Stat label={t("likes")} value={place.likes} />
        </div>
        <h2 className="mt-5 text-base font-bold">{t("description")}</h2>
        <p className="whitespace-pre-wrap text-sm text-[#444]">{place.description || "—"}</p>
        {place.stats && (
          <div className="mt-4 grid grid-cols-4 gap-2 text-center">
            <Stat label={t("parts")} value={place.stats.parts} />
            <Stat label={t("scripts")} value={place.stats.scripts} />
            <Stat label={t("particles")} value={place.stats.particles} />
            <Stat label={t("images")} value={place.stats.images} />
          </div>
        )}
      </div>
    </div>
  );
}

function Stat({ label, value, icon }: { label: string; value: number; icon?: React.ReactNode }) {
  return (
    <div className="rounded border border-[#eee] py-2">
      <div className="flex items-center justify-center gap-1 text-base font-bold text-[#222]">
        {icon}
        {value}
      </div>
      <div className="text-[11px] uppercase tracking-wide text-[#888]">{label}</div>
    </div>
  );
}
