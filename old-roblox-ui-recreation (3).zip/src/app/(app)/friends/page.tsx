"use client";
import { useEffect, useState } from "react";
import { useApp } from "@/components/AppShell";
import { fetchJson, post, UserRow, type UserSummary } from "@/components/Cards";

export default function FriendsPage() {
  const { t } = useApp();
  const [data, setData] = useState<{ friends: UserSummary[]; incoming: UserSummary[]; outgoing: UserSummary[] } | null>(null);
  const load = () => fetchJson<{ friends: UserSummary[]; incoming: UserSummary[]; outgoing: UserSummary[] }>("/api/friends").then(setData);
  useEffect(() => {
    load();
  }, []);

  const act = async (action: string, userId: number) => {
    await post("/api/friends", { action, userId });
    load();
  };

  return (
    <div>
      {data && data.incoming.length > 0 && (
        <>
          <h2 className="px-4 pt-4 pb-1 text-base font-bold">{t("friendRequests")}</h2>
          {data.incoming.map((u) => (
            <UserRow
              key={u.id}
              user={u}
              right={
                <button onClick={() => act("accept", u.id)} className="rounded bg-[#5fbf72] px-3 py-1 text-xs font-semibold text-white">
                  {t("accept")}
                </button>
              }
            />
          ))}
        </>
      )}
      <h2 className="px-4 pt-4 pb-1 text-base font-bold">
        {t("friends")} ({data?.friends.length ?? 0})
      </h2>
      {data && data.friends.length === 0 && <p className="px-4 text-sm text-[#777]">{t("noFriends")}</p>}
      {data?.friends.map((u) => (
        <UserRow
          key={u.id}
          user={u}
          right={
            <span className="text-xs text-[#888]">
              {u.presence === "ingame" ? t("inGame") : u.presence === "online" ? t("online") : t("offline")}
            </span>
          }
        />
      ))}
      {data && data.outgoing.length > 0 && (
        <>
          <h2 className="px-4 pt-4 pb-1 text-base font-bold">{t("requested")}</h2>
          {data.outgoing.map((u) => (
            <UserRow key={u.id} user={u} right={<span className="text-xs text-[#888]">{t("requested")}</span>} />
          ))}
        </>
      )}
    </div>
  );
}
