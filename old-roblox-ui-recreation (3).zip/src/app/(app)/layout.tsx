import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import AppShell from "@/components/AppShell";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: ReactNode }) {
  const user = await getCurrentUser();
  if (!user) redirect("/");
  return (
    <AppShell
      initialMe={{
        id: user.id,
        username: user.username,
        gender: user.gender,
        avatar: user.avatar,
        description: user.description,
        robux: user.robux,
        language: user.language,
      }}
    >
      {children}
    </AppShell>
  );
}
