"use client";
import { useEffect, useState } from "react";
import { inputCls, useApp } from "@/components/AppShell";
import { fetchJson, GameCard, UserRow, type PlaceSummary, type UserSummary } from "@/components/Cards";

export default function SearchPage() {
  const { t } = useApp();
  const [q, setQ] = useState("");
  const [users, setUsers] = useState<UserSummary[]>([]);
  const [places, setPlaces] = useState<PlaceSummary[]>([]);

  useEffect(() => {
    const h = setTimeout(() => {
      fetchJson<{ users: UserSummary[] }>(`/api/users?q=${encodeURIComponent(q)}`).then((j) => setUsers(j.users ?? []));
      fetchJson<{ places: PlaceSummary[] }>(`/api/places?q=${encodeURIComponent(q)}`).then((j) => setPlaces(j.places ?? []));
    }, 250);
    return () => clearTimeout(h);
  }, [q]);

  return (
    <div>
      <div className="p-4">
        <input className={inputCls} placeholder={t("searchPlaceholder")} value={q} onChange={(e) => setQ(e.target.value)} autoFocus />
      </div>
      <h2 className="px-4 pb-1 text-base font-bold">{t("players")}</h2>
      {users.length === 0 && <p className="px-4 pb-2 text-sm text-[#777]">{t("nothingFound")}</p>}
      {users.map((u) => (
        <UserRow key={u.id} user={u} />
      ))}
      <h2 className="px-4 pb-1 pt-4 text-base font-bold">{t("games")}</h2>
      <div className="grid grid-cols-2 gap-3 px-4 sm:grid-cols-3 md:grid-cols-4">
        {places.length === 0 && <p className="col-span-full text-sm text-[#777]">{t("nothingFound")}</p>}
        {places.map((p) => (
          <GameCard key={p.id} place={p} />
        ))}
      </div>
    </div>
  );
}
