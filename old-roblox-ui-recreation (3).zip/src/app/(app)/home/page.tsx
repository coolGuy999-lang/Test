"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useApp } from "@/components/AppShell";
import AvatarView from "@/components/AvatarView";
import { fetchJson, FriendTile, GameCard, SectionTitle, type PlaceSummary, type UserSummary } from "@/components/Cards";

export default function HomePage() {
  const { me, t } = useApp();
  const [friends, setFriends] = useState<UserSummary[] | null>(null);
  const [incoming, setIncoming] = useState(0);
  const [recent, setRecent] = useState<PlaceSummary[] | null>(null);
  const [popular, setPopular] = useState<PlaceSummary[] | null>(null);

  useEffect(() => {
    const load = () => {
      fetchJson<{ friends: UserSummary[]; incoming: UserSummary[] }>("/api/friends").then((j) => {
        setFriends(j.friends ?? []);
        setIncoming(j.incoming?.length ?? 0);
      });
      fetchJson<{ places: PlaceSummary[] }>("/api/places?sort=recent").then((j) => setRecent(j.places ?? []));
      fetchJson<{ places: PlaceSummary[] }>("/api/places?sort=popular").then((j) => setPopular(j.places ?? []));
    };
    load();
    const id = setInterval(load, 20000);
    return () => clearInterval(id);
  }, []);

  return (
    <div>
      <div className="flex items-center gap-3 px-4 pt-4">
        <Link href={`/users/${me.id}`}>
          <AvatarView avatar={me.avatar} size={72} className="rounded-full border border-[#e3e3e3]" />
        </Link>
        <div>
          <Link href={`/users/${me.id}`} className="text-lg font-bold text-[#222]">
            {me.username}
          </Link>
        </div>
      </div>

      <SectionTitle
        action={
          <Link href="/friends" className="text-sm font-semibold text-[#1e78c8]">
            {t("seeAll")}
            {incoming > 0 && <span className="ml-1 rounded-full bg-[#d0342c] px-1.5 text-[10px] text-white">{incoming}</span>}
          </Link>
        }
      >
        {t("friends")} ({friends?.length ?? 0})
      </SectionTitle>
      <div className="no-scrollbar flex gap-3 overflow-x-auto px-4 pb-2">
        {friends && friends.length === 0 && <p className="text-sm text-[#777]">{t("noFriends")}</p>}
        {friends?.map((f) => (
          <FriendTile key={f.id} user={f} />
        ))}
      </div>

      <SectionTitle>{t("recentlyPlayed")}</SectionTitle>
      <div className="grid grid-cols-2 gap-3 px-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
        {recent && recent.length === 0 && <p className="col-span-full text-sm text-[#777]">{t("noGames")}</p>}
        {recent?.map((p) => (
          <GameCard key={p.id} place={p} />
        ))}
      </div>

      <SectionTitle
        action={
          <Link href="/games" className="text-sm font-semibold text-[#1e78c8]">
            {t("seeAll")}
          </Link>
        }
      >
        {t("popular")}
      </SectionTitle>
      <div className="grid grid-cols-2 gap-3 px-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
        {popular?.slice(0, 12).map((p) => (
          <GameCard key={p.id} place={p} />
        ))}
      </div>
    </div>
  );
}
