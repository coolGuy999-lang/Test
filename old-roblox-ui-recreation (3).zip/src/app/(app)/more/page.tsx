"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { greenBtn, inputCls, outlineBtn, useApp } from "@/components/AppShell";
import { post } from "@/components/Cards";
import { GearIcon, GlobeIcon, HammerIcon, LogoutIcon } from "@/components/Icons";
import { LANGS } from "@/lib/i18n";

export default function MorePage() {
  const { me, setMe, lang, setLang, t } = useApp();
  const router = useRouter();
  const [desc, setDesc] = useState(me.description);
  const [pw, setPw] = useState({ current: "", next: "" });
  const [msg, setMsg] = useState<string | null>(null);

  const saveDesc = async () => {
    await post("/api/users", { action: "description", description: desc });
    setMe({ description: desc });
    setMsg(t("saved"));
  };
  const changePw = async () => {
    const j = await post<{ ok?: boolean; error?: string }>("/api/users", { action: "password", ...pw });
    setMsg(j.ok ? t("saved") : j.error ?? "Error");
    if (j.ok) setPw({ current: "", next: "" });
  };
  const logout = async () => {
    await fetch("/api/presence", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: "offline" }) });
    await post("/api/auth", { action: "logout" });
    router.replace("/");
    router.refresh();
  };

  return (
    <div className="mx-auto max-w-xl">
      <Link href="/create" className="flex items-center gap-3 border-b border-[#eee] px-4 py-4 hover:bg-[#fafafa]">
        <HammerIcon size={26} className="text-[#5b6270]" />
        <span className="text-base font-semibold">{t("create")}</span>
      </Link>

      <section className="border-b border-[#eee] px-4 py-4">
        <div className="mb-2 flex items-center gap-2 text-base font-semibold">
          <GlobeIcon size={22} className="text-[#5b6270]" /> {t("language")}
        </div>
        <div className="flex gap-2">
          {LANGS.map((l) => (
            <button
              key={l}
              onClick={() => setLang(l)}
              className={`rounded border px-4 py-1.5 text-sm font-semibold ${lang === l ? "border-[#1e78c8] bg-[#1e78c8] text-white" : "border-[#d5d5d5] text-[#444]"}`}
            >
              {l === "en" ? "English" : "Русский"}
            </button>
          ))}
        </div>
      </section>

      <section className="border-b border-[#eee] px-4 py-4">
        <div className="mb-2 flex items-center gap-2 text-base font-semibold">
          <GearIcon size={22} className="text-[#5b6270]" /> {t("settings")}
        </div>
        <label className="text-xs font-semibold text-[#666]">{t("description")}</label>
        <textarea className={`${inputCls} mt-1 h-24`} value={desc} onChange={(e) => setDesc(e.target.value)} />
        <button onClick={saveDesc} className={`${greenBtn} mt-2`}>
          {t("save")}
        </button>

        <div className="mt-5 text-sm font-semibold">{t("changePassword")}</div>
        <input className={`${inputCls} mt-2`} type="password" placeholder={t("currentPassword")} value={pw.current} onChange={(e) => setPw({ ...pw, current: e.target.value })} />
        <input className={`${inputCls} mt-2`} type="password" placeholder={t("newPassword")} value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} />
        <button onClick={changePw} className={`${outlineBtn} mt-2`}>
          {t("changePassword")}
        </button>
        {msg && <p className="mt-2 text-sm text-[#2a9d4b]">{msg}</p>}
      </section>

      <button onClick={logout} className="flex w-full items-center gap-3 px-4 py-4 text-left text-base font-semibold text-[#d0342c] hover:bg-[#fafafa]">
        <LogoutIcon size={22} /> {t("logout")}
      </button>
    </div>
  );
}
