"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useApp } from "@/components/AppShell";
import AvatarView from "@/components/AvatarView";
import { fetchJson, PresenceDot, type UserSummary } from "@/components/Cards";

type Conv = { user: UserSummary; lastText: string; lastAt: string; unread: number; fromMe: boolean };

export default function ChatPage() {
  const { t } = useApp();
  const [convs, setConvs] = useState<Conv[] | null>(null);
  const [friends, setFriends] = useState<UserSummary[]>([]);

  useEffect(() => {
    const load = () => {
      fetchJson<{ conversations: Conv[] }>("/api/chat").then((j) => setConvs(j.conversations ?? []));
      fetchJson<{ friends: UserSummary[] }>("/api/friends").then((j) => setFriends(j.friends ?? []));
    };
    load();
    const id = setInterval(load, 8000);
    return () => clearInterval(id);
  }, []);

  const shown = new Set(convs?.map((c) => c.user.id));
  const otherFriends = friends.filter((f) => !shown.has(f.id));

  return (
    <div>
      <h2 className="px-4 pt-4 pb-1 text-base font-bold">{t("conversations")}</h2>
      {convs && convs.length === 0 && <p className="px-4 pb-2 text-sm text-[#777]">{t("noChats")}</p>}
      {convs?.map((c) => (
        <Link key={c.user.id} href={`/chat/${c.user.id}`} className="flex items-center gap-3 border-b border-[#eee] px-4 py-2">
          <div className="relative">
            <AvatarView avatar={c.user.avatar} size={48} className="rounded-full" />
            <PresenceDot presence={c.user.presence} className="bottom-0 right-0" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-sm font-semibold">{c.user.username}</div>
            <div className="truncate text-xs text-[#777]">
              {c.fromMe ? "You: " : ""}
              {c.lastText}
            </div>
          </div>
          {c.unread > 0 && <span className="rounded-full bg-[#3aa6e0] px-2 py-0.5 text-xs font-bold text-white">{c.unread}</span>}
        </Link>
      ))}
      {otherFriends.length > 0 && (
        <>
          <h2 className="px-4 pt-4 pb-1 text-base font-bold">{t("friends")}</h2>
          {otherFriends.map((f) => (
            <Link key={f.id} href={`/chat/${f.id}`} className="flex items-center gap-3 border-b border-[#eee] px-4 py-2">
              <div className="relative">
                <AvatarView avatar={f.avatar} size={48} className="rounded-full" />
                <PresenceDot presence={f.presence} className="bottom-0 right-0" />
              </div>
              <div className="text-sm font-semibold">{f.username}</div>
            </Link>
          ))}
        </>
      )}
    </div>
  );
}
