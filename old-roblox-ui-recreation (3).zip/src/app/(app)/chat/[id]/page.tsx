"use client";
import { useParams } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { inputCls, useApp } from "@/components/AppShell";
import { fetchJson, post, type UserSummary } from "@/components/Cards";
import AvatarView from "@/components/AvatarView";

type Msg = { id: number; senderId: number; receiverId: number; text: string; createdAt: string };

export default function ChatThreadPage() {
  const id = useParams<{ id: string }>()?.id ?? "";
  const { me, t } = useApp();
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [user, setUser] = useState<UserSummary | null>(null);
  const [text, setText] = useState("");
  const bottom = useRef<HTMLDivElement>(null);

  const load = () =>
    fetchJson<{ messages: Msg[]; user: UserSummary | null }>(`/api/chat?with=${id}`).then((j) => {
      setMsgs(j.messages ?? []);
      setUser(j.user);
    });
  useEffect(() => {
    load();
    const iv = setInterval(load, 3000);
    return () => clearInterval(iv);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);
  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs.length]);

  const send = async () => {
    const v = text.trim();
    if (!v) return;
    setText("");
    await post("/api/chat", { to: Number(id), text: v });
    load();
  };

  return (
    <div className="flex h-[calc(100vh-8.5rem)] flex-col">
      {user && (
        <div className="flex items-center gap-2 border-b border-[#eee] px-4 py-2">
          <AvatarView avatar={user.avatar} size={36} className="rounded-full" />
          <span className="text-sm font-semibold">{user.username}</span>
        </div>
      )}
      <div className="flex-1 space-y-2 overflow-y-auto p-4">
        {msgs.map((m) => {
          const mine = m.senderId === me.id;
          return (
            <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[75%] rounded-2xl px-3 py-2 text-sm ${mine ? "bg-[#3aa6e0] text-white" : "bg-[#f0f0f0] text-[#222]"}`}>
                {m.text}
              </div>
            </div>
          );
        })}
        <div ref={bottom} />
      </div>
      <form
        className="flex gap-2 border-t border-[#eee] p-3"
        onSubmit={(e) => {
          e.preventDefault();
          send();
        }}
      >
        <input className={inputCls} placeholder={t("typeMessage")} value={text} onChange={(e) => setText(e.target.value)} />
        <button className="rounded bg-[#3aa6e0] px-4 text-sm font-semibold text-white">{t("send")}</button>
      </form>
    </div>
  );
}
