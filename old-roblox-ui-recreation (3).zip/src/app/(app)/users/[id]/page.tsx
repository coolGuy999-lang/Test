"use client";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import { useApp } from "@/components/AppShell";
import AvatarView from "@/components/AvatarView";
import { fetchJson, PlaceThumb, post, PresenceDot, type UserSummary } from "@/components/Cards";
import { AddPersonIcon, MessageIcon } from "@/components/Icons";

type Profile = {
  user: UserSummary & { description: string; createdAt: string };
  counts: { friends: number; followers: number; following: number };
  friendStatus: "none" | "friends" | "outgoing" | "incoming";
  isFollowing: boolean;
  creations: { id: number; name: string; thumbnail: string | null; visits: number }[];
};

export default function ProfilePage() {
  const id = useParams<{ id: string }>()?.id ?? "";
  const { me, t } = useApp();
  const [p, setP] = useState<Profile | null>(null);
  const [tab, setTab] = useState<"about" | "creations">("about");
  const load = () => fetchJson<Profile>(`/api/users?id=${id}`).then(setP);
  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (!p || !p.user) return <div className="p-6 text-center text-sm text-[#777]">{t("loading")}...</div>;
  const isMe = p.user.id === me.id;

  const friendAct = async () => {
    const action = p.friendStatus === "friends" ? "remove" : p.friendStatus === "incoming" ? "accept" : "add";
    await post("/api/friends", { action, userId: p.user.id });
    load();
  };
  const followAct = async () => {
    await post("/api/friends", { action: p.isFollowing ? "unfollow" : "follow", userId: p.user.id });
    load();
  };
  const friendLabel =
    p.friendStatus === "friends" ? t("unfriend") : p.friendStatus === "outgoing" ? t("requested") : p.friendStatus === "incoming" ? t("accept") : t("addFriend");

  return (
    <div className="mx-auto max-w-2xl">
      <div className="flex flex-col items-center pt-6">
        <div className="relative">
          <AvatarView avatar={p.user.avatar} size={120} className="rounded-full border border-[#e3e3e3]" />
          <PresenceDot presence={p.user.presence} className="bottom-2 right-2 h-5 w-5" />
        </div>
        <h1 className="mt-2 text-xl font-bold">{p.user.username}</h1>
        <div className="mt-3 flex w-full max-w-sm justify-around text-center">
          <Stat label={t("friends")} value={p.counts.friends} />
          <Stat label={t("followers")} value={p.counts.followers} />
          <Stat label={t("following")} value={p.counts.following} />
        </div>
      </div>

      {!isMe && (
        <div className="mx-4 mt-4 flex overflow-hidden rounded border border-[#d5d5d5]">
          <button onClick={friendAct} className="flex flex-1 flex-col items-center gap-1 py-2 text-xs font-semibold text-[#333] hover:bg-[#f5f5f5]">
            <AddPersonIcon size={22} className={p.friendStatus === "friends" ? "text-[#2a9d4b]" : "text-[#555]"} />
            {friendLabel}
          </button>
          <div className="w-px bg-[#d5d5d5]" />
          <Link href={`/chat/${p.user.id}`} className="flex flex-1 flex-col items-center gap-1 py-2 text-xs font-semibold text-[#333] hover:bg-[#f5f5f5]">
            <MessageIcon size={22} className="text-[#555]" />
            {t("message")}
          </Link>
        </div>
      )}
      {!isMe && (
        <div className="px-4 pt-2 text-center">
          <button onClick={followAct} className="text-xs font-semibold text-[#1e78c8]">
            {p.isFollowing ? t("unfollow") : t("follow")}
          </button>
        </div>
      )}

      <p className="whitespace-pre-wrap px-4 pt-4 text-sm text-[#444]">{p.user.description || (isMe ? "" : "")}</p>

      <div className="mt-4 flex border-b border-[#e3e3e3]">
        {(["about", "creations"] as const).map((k) => (
          <button
            key={k}
            onClick={() => setTab(k)}
            className={`flex-1 py-2 text-sm font-semibold ${tab === k ? "border-b-2 border-[#1e78c8] text-[#1e78c8]" : "text-[#666]"}`}
          >
            {t(k)}
          </button>
        ))}
      </div>

      {tab === "about" ? (
        <div className="flex flex-col items-center gap-3 px-4 py-6">
          <p className="text-xs text-[#888]">
            {t("joined")}: {new Date(p.user.createdAt).toLocaleDateString()}
          </p>
          <AvatarView avatar={p.user.avatar} mode="full" size={300} className="rounded" />
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3 p-4 sm:grid-cols-3">
          {p.creations.length === 0 && <p className="col-span-full text-sm text-[#777]">{t("noCreations")}</p>}
          {p.creations.map((c) => (
            <Link key={c.id} href={`/games/${c.id}`} className="block">
              <PlaceThumb place={c} />
              <div className="mt-1 truncate text-sm font-semibold">{c.name}</div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <div className="text-xs font-semibold text-[#666]">{label}</div>
      <div className="text-lg font-bold text-[#222]">{value}</div>
    </div>
  );
}
