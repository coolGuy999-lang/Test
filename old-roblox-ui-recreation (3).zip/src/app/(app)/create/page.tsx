"use client";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { greenBtn, inputCls, outlineBtn, useApp } from "@/components/AppShell";
import { fetchJson, PlaceThumb, post, type PlaceSummary } from "@/components/Cards";
import { PlayIcon, UploadIcon } from "@/components/Icons";

type Stats = { parts: number; models: number; scripts: number; particles: number; images: number; other: number };

export default function CreatePage() {
  const { t } = useApp();
  const [places, setPlaces] = useState<PlaceSummary[] | null>(null);
  const [busy, setBusy] = useState<number | null>(null);
  const [status, setStatus] = useState<Record<number, string>>({});
  const [editing, setEditing] = useState<{ id: number; name: string; description: string } | null>(null);
  const fileRefs = useRef<Record<number, HTMLInputElement | null>>({});
  const thumbRefs = useRef<Record<number, HTMLInputElement | null>>({});

  const load = () => fetchJson<{ places: (PlaceSummary & { description: string })[] }>("/api/places?mine=1").then((j) => setPlaces(j.places ?? []));
  useEffect(() => {
    load();
  }, []);

  const create = async () => {
    await post("/api/places", { action: "create" });
    load();
  };

  const upload = async (placeId: number, file: File) => {
    setBusy(placeId);
    setStatus((s) => ({ ...s, [placeId]: `${t("loading")}...` }));
    const fd = new FormData();
    fd.append("placeId", String(placeId));
    fd.append("file", file);
    const r = await fetch("/api/places", { method: "POST", body: fd });
    const j = (await r.json()) as { ok?: boolean; error?: string; stats?: Stats; parts?: number };
    setBusy(null);
    if (!r.ok || !j.ok) {
      setStatus((s) => ({ ...s, [placeId]: j.error ?? "Upload failed" }));
      return;
    }
    const st = j.stats!;
    setStatus((s) => ({
      ...s,
      [placeId]: `OK: ${t("parts")} ${st.parts}, ${t("scripts")} ${st.scripts}, ${t("particles")} ${st.particles}, ${t("images")} ${st.images}`,
    }));
    load();
  };

  const setThumb = async (placeId: number, file: File) => {
    const dataUrl = await downscale(file);
    await post("/api/places", { action: "update", placeId, thumbnail: dataUrl });
    load();
  };

  const saveEdit = async () => {
    if (!editing) return;
    await post("/api/places", { action: "update", placeId: editing.id, name: editing.name, description: editing.description });
    setEditing(null);
    load();
  };

  const remove = async (placeId: number) => {
    if (!confirm("Delete this place?")) return;
    await post("/api/places", { action: "delete", placeId });
    load();
  };

  return (
    <div className="mx-auto max-w-2xl">
      <div className="flex items-center justify-between px-4 pt-4">
        <h2 className="text-base font-bold">{t("myPlaces")}</h2>
        <button onClick={create} className={greenBtn}>
          {t("createPlace")}
        </button>
      </div>
      {places && places.length === 0 && <p className="px-4 pt-3 text-sm text-[#777]">{t("noPlaces")}</p>}
      <div className="space-y-4 p-4">
        {places?.map((p) => (
          <div key={p.id} className="rounded border border-[#e3e3e3] p-3">
            <div className="flex gap-3">
              <PlaceThumb place={p} className="w-40 shrink-0" />
              <div className="min-w-0 flex-1">
                {editing?.id === p.id ? (
                  <div className="space-y-2">
                    <input className={inputCls} value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} placeholder={t("placeName")} />
                    <textarea className={`${inputCls} h-20`} value={editing.description} onChange={(e) => setEditing({ ...editing, description: e.target.value })} placeholder={t("description")} />
                    <div className="flex gap-2">
                      <button onClick={saveEdit} className={greenBtn}>
                        {t("save")}
                      </button>
                      <button onClick={() => setEditing(null)} className={outlineBtn}>
                        {t("cancel")}
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="truncate text-base font-bold">{p.name}</div>
                    <div className="text-xs text-[#777]">
                      {t("visits")}: {p.visits} · {t("likes")}: {p.likes}
                    </div>
                    <div className="mt-2 flex flex-wrap gap-2">
                      <Link href={`/play/${p.id}`} className={`${greenBtn} inline-flex items-center gap-1`}>
                        <PlayIcon size={16} /> {t("play")}
                      </Link>
                      <button onClick={() => setEditing({ id: p.id, name: p.name, description: (p as PlaceSummary & { description?: string }).description ?? "" })} className={outlineBtn}>
                        {t("edit")}
                      </button>
                      <button onClick={() => remove(p.id)} className={`${outlineBtn} text-[#d0342c]`}>
                        {t("delete")}
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <input
                ref={(el) => {
                  fileRefs.current[p.id] = el;
                }}
                type="file"
                accept=".rbxl,.rbxlx,.rbxm,.rbxmx"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) upload(p.id, f);
                  e.target.value = "";
                }}
              />
              <button disabled={busy === p.id} onClick={() => fileRefs.current[p.id]?.click()} className={`${outlineBtn} inline-flex items-center gap-1`}>
                <UploadIcon size={16} /> {t("uploadPlace")}
              </button>
              <input
                ref={(el) => {
                  thumbRefs.current[p.id] = el;
                }}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) setThumb(p.id, f);
                  e.target.value = "";
                }}
              />
              <button onClick={() => thumbRefs.current[p.id]?.click()} className={outlineBtn}>
                {t("thumbnail")}
              </button>
            </div>
            {status[p.id] && <p className="mt-2 text-xs text-[#444]">{status[p.id]}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}

function downscale(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const w = 640, h = 360;
      const c = document.createElement("canvas");
      c.width = w;
      c.height = h;
      const ctx = c.getContext("2d")!;
      const scale = Math.max(w / img.width, h / img.height);
      const dw = img.width * scale, dh = img.height * scale;
      ctx.drawImage(img, (w - dw) / 2, (h - dh) / 2, dw, dh);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL("image/jpeg", 0.8));
    };
    img.onerror = reject;
    img.src = url;
  });
}
