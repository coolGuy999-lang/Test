import { redirect } from "next/navigation";
import AuthScreen from "@/components/AuthScreen";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function RootPage() {
  const user = await getCurrentUser();
  if (user) redirect("/home");
  return <AuthScreen />;
}
