import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import {
  createSession,
  defaultAvatar,
  destroySession,
  getCurrentUser,
  hashPassword,
  publicUser,
  verifyPassword,
} from "@/lib/auth";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ user: null });
  return NextResponse.json({ user: { ...publicUser(user), robux: user.robux, language: user.language } });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const action = body.action as string;

  if (action === "logout") {
    await destroySession();
    return NextResponse.json({ ok: true });
  }

  if (action === "login") {
    const username = String(body.username ?? "").trim();
    const password = String(body.password ?? "");
    const [user] = await db.select().from(users).where(eq(users.username, username)).limit(1);
    if (!user || !verifyPassword(password, user.passwordHash)) {
      return NextResponse.json({ error: "Incorrect username or password." }, { status: 401 });
    }
    await createSession(user.id);
    await db.update(users).set({ presence: "online", lastSeen: new Date() }).where(eq(users.id, user.id));
    return NextResponse.json({ ok: true, user: publicUser(user) });
  }

  if (action === "signup") {
    const username = String(body.username ?? "").trim();
    const password = String(body.password ?? "");
    const confirm = String(body.confirm ?? "");
    const gender = body.gender === "female" ? "female" : "male";
    const { month, day, year } = body;
    if (!/^[A-Za-z0-9_]{3,20}$/.test(username)) {
      return NextResponse.json({ error: "Username must be 3-20 characters (letters, numbers, _)." }, { status: 400 });
    }
    if (password.length < 8) {
      return NextResponse.json({ error: "Password must be at least 8 characters." }, { status: 400 });
    }
    if (password !== confirm) {
      return NextResponse.json({ error: "Passwords do not match." }, { status: 400 });
    }
    if (!month || !day || !year) {
      return NextResponse.json({ error: "Please enter your birthday." }, { status: 400 });
    }
    const existing = await db.select({ id: users.id }).from(users).where(eq(users.username, username)).limit(1);
    if (existing.length) {
      return NextResponse.json({ error: "This username is already taken." }, { status: 409 });
    }
    const [user] = await db
      .insert(users)
      .values({
        username,
        passwordHash: hashPassword(password),
        birthday: `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`,
        gender,
        avatar: defaultAvatar(gender),
        presence: "online",
        lastRobuxClaim: new Date().toISOString().slice(0, 10),
      })
      .returning();
    await createSession(user.id);
    return NextResponse.json({ ok: true, user: publicUser(user) });
  }

  return NextResponse.json({ error: "Unknown action" }, { status: 400 });
}
