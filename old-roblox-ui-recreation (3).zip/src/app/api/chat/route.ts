import { NextResponse } from "next/server";
import { and, desc, eq, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { messages, users } from "@/db/schema";
import { getCurrentUser, publicUser } from "@/lib/auth";

export async function GET(req: Request) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const url = new URL(req.url);
  const withId = url.searchParams.get("with");

  if (withId) {
    const other = Number(withId);
    const rows = await db
      .select()
      .from(messages)
      .where(
        or(
          and(eq(messages.senderId, me.id), eq(messages.receiverId, other)),
          and(eq(messages.senderId, other), eq(messages.receiverId, me.id)),
        ),
      )
      .orderBy(desc(messages.createdAt))
      .limit(100);
    await db
      .update(messages)
      .set({ read: true })
      .where(and(eq(messages.senderId, other), eq(messages.receiverId, me.id), eq(messages.read, false)));
    const [u] = await db.select().from(users).where(eq(users.id, other)).limit(1);
    return NextResponse.json({ messages: rows.reverse(), user: u ? publicUser(u) : null });
  }

  // conversation list: latest message per partner
  const rows = await db.execute(sql`
    select distinct on (partner) partner, text, created_at, sender_id,
      (select count(*)::int from messages m2 where m2.sender_id = partner and m2.receiver_id = ${me.id} and m2.read = false) as unread
    from (
      select case when sender_id = ${me.id} then receiver_id else sender_id end as partner, text, created_at, sender_id
      from messages where sender_id = ${me.id} or receiver_id = ${me.id}
    ) t
    order by partner, created_at desc
  `);
  const list = rows.rows as { partner: number; text: string; created_at: string; sender_id: number; unread: number }[];
  const ids = list.map((r) => r.partner);
  const people = ids.length
    ? await db
        .select()
        .from(users)
        .where(or(...ids.map((id) => eq(users.id, id))))
    : [];
  const byId = new Map(people.map((p) => [p.id, publicUser(p)]));
  const conversations = list
    .map((r) => ({
      user: byId.get(r.partner),
      lastText: r.text,
      lastAt: r.created_at,
      unread: r.unread,
      fromMe: r.sender_id === me.id,
    }))
    .filter((c) => c.user)
    .sort((a, b) => new Date(b.lastAt).getTime() - new Date(a.lastAt).getTime());
  return NextResponse.json({ conversations });
}

export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const to = Number(body.to);
  const text = String(body.text ?? "").trim().slice(0, 500);
  if (!to || !text) return NextResponse.json({ error: "Bad request" }, { status: 400 });
  const [m] = await db.insert(messages).values({ senderId: me.id, receiverId: to, text }).returning();
  return NextResponse.json({ ok: true, message: m });
}
