import { NextResponse } from "next/server";
import { and, desc, eq, ilike, sql } from "drizzle-orm";
import { db } from "@/db";
import { placeFavorites, placeLikes, placeVisits, places, users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { defaultWorld, parsePlaceFile } from "@/lib/rbx";

const likeCount = sql<number>`(select count(*)::int from place_likes pl where pl.place_id = ${places.id})`;
const playingCount = sql<number>`(select count(*)::int from users u2 where u2.current_place_id = ${places.id} and u2.presence = 'ingame' and u2.last_seen > now() - interval '90 seconds')`;

const summary = {
  id: places.id,
  name: places.name,
  description: places.description,
  thumbnail: places.thumbnail,
  visits: places.visits,
  ownerId: places.ownerId,
  ownerName: users.username,
  createdAt: places.createdAt,
  likes: likeCount,
  playing: playingCount,
};

export async function GET(req: Request) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const url = new URL(req.url);
  const sort = url.searchParams.get("sort") ?? "popular";
  const q = url.searchParams.get("q");
  const mine = url.searchParams.get("mine");

  const base = db.select(summary).from(places).innerJoin(users, eq(places.ownerId, users.id));

  if (mine) {
    const rows = await base.where(eq(places.ownerId, me.id)).orderBy(desc(places.updatedAt));
    return NextResponse.json({ places: rows });
  }
  if (q !== null) {
    const rows = await base
      .where(and(eq(places.isPublic, true), ilike(places.name, `%${q.trim()}%`)))
      .orderBy(desc(places.visits))
      .limit(30);
    return NextResponse.json({ places: rows });
  }
  if (sort === "recent") {
    const rows = await db
      .select({ ...summary, lastPlayed: placeVisits.lastPlayed })
      .from(placeVisits)
      .innerJoin(places, eq(placeVisits.placeId, places.id))
      .innerJoin(users, eq(places.ownerId, users.id))
      .where(eq(placeVisits.userId, me.id))
      .orderBy(desc(placeVisits.lastPlayed))
      .limit(20);
    return NextResponse.json({ places: rows });
  }
  if (sort === "favorites") {
    const rows = await db
      .select(summary)
      .from(placeFavorites)
      .innerJoin(places, eq(placeFavorites.placeId, places.id))
      .innerJoin(users, eq(places.ownerId, users.id))
      .where(eq(placeFavorites.userId, me.id))
      .orderBy(desc(places.visits));
    return NextResponse.json({ places: rows });
  }
  const order =
    sort === "top" ? [desc(likeCount), desc(places.visits)] : sort === "newest" ? [desc(places.createdAt)] : [desc(playingCount), desc(places.visits), desc(places.createdAt)];
  const rows = await base.where(eq(places.isPublic, true)).orderBy(...order).limit(50);
  return NextResponse.json({ places: rows });
}

export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const ct = req.headers.get("content-type") ?? "";

  if (ct.includes("multipart/form-data")) {
    const form = await req.formData();
    const placeId = Number(form.get("placeId"));
    const file = form.get("file");
    if (!placeId || !(file instanceof File)) return NextResponse.json({ error: "Bad upload" }, { status: 400 });
    const [place] = await db.select().from(places).where(eq(places.id, placeId)).limit(1);
    if (!place || place.ownerId !== me.id) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    if (file.size > 40 * 1024 * 1024) return NextResponse.json({ error: "File too large (max 40 MB)" }, { status: 400 });
    try {
      const data = new Uint8Array(await file.arrayBuffer());
      const world = parsePlaceFile(file.name, data);
      await db.update(places).set({ world, updatedAt: new Date() }).where(eq(places.id, placeId));
      return NextResponse.json({ ok: true, stats: world.stats, parts: world.parts.length });
    } catch (e) {
      return NextResponse.json({ error: e instanceof Error ? e.message : "Failed to parse place file" }, { status: 400 });
    }
  }

  const body = await req.json().catch(() => ({}));
  const action = body.action as string;

  if (action === "create") {
    const count = await db.select({ c: sql<number>`count(*)::int` }).from(places).where(eq(places.ownerId, me.id));
    const name = String(body.name ?? `${me.username}'s Place Number: ${(count[0]?.c ?? 0) + 1}`).slice(0, 60);
    const [place] = await db
      .insert(places)
      .values({ ownerId: me.id, name, world: defaultWorld() })
      .returning({ id: places.id });
    return NextResponse.json({ ok: true, id: place.id });
  }

  const placeId = Number(body.placeId);
  if (!placeId) return NextResponse.json({ error: "Missing placeId" }, { status: 400 });

  if (action === "like") {
    const [ex] = await db
      .select()
      .from(placeLikes)
      .where(and(eq(placeLikes.userId, me.id), eq(placeLikes.placeId, placeId)));
    if (ex) await db.delete(placeLikes).where(and(eq(placeLikes.userId, me.id), eq(placeLikes.placeId, placeId)));
    else await db.insert(placeLikes).values({ userId: me.id, placeId });
    return NextResponse.json({ ok: true, liked: !ex });
  }
  if (action === "favorite") {
    const [ex] = await db
      .select()
      .from(placeFavorites)
      .where(and(eq(placeFavorites.userId, me.id), eq(placeFavorites.placeId, placeId)));
    if (ex)
      await db.delete(placeFavorites).where(and(eq(placeFavorites.userId, me.id), eq(placeFavorites.placeId, placeId)));
    else await db.insert(placeFavorites).values({ userId: me.id, placeId });
    return NextResponse.json({ ok: true, favorited: !ex });
  }
  if (action === "update") {
    const [place] = await db.select().from(places).where(eq(places.id, placeId)).limit(1);
    if (!place || place.ownerId !== me.id) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const patch: Partial<typeof places.$inferInsert> = { updatedAt: new Date() };
    if (typeof body.name === "string" && body.name.trim()) patch.name = body.name.trim().slice(0, 60);
    if (typeof body.description === "string") patch.description = body.description.slice(0, 1000);
    if (typeof body.thumbnail === "string") {
      if (body.thumbnail.length > 600_000) return NextResponse.json({ error: "Image too large" }, { status: 400 });
      patch.thumbnail = body.thumbnail.startsWith("data:image/") ? body.thumbnail : null;
    }
    await db.update(places).set(patch).where(eq(places.id, placeId));
    return NextResponse.json({ ok: true });
  }
  if (action === "delete") {
    await db.delete(places).where(and(eq(places.id, placeId), eq(places.ownerId, me.id)));
    return NextResponse.json({ ok: true });
  }
  if (action === "visit") {
    await db
      .insert(placeVisits)
      .values({ userId: me.id, placeId, lastPlayed: new Date() })
      .onConflictDoUpdate({ target: [placeVisits.userId, placeVisits.placeId], set: { lastPlayed: new Date() } });
    await db.update(places).set({ visits: sql`${places.visits} + 1` }).where(eq(places.id, placeId));
    return NextResponse.json({ ok: true });
  }
  return NextResponse.json({ error: "Unknown action" }, { status: 400 });
}
