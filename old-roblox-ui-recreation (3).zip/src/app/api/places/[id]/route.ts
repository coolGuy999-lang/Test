import { NextResponse } from "next/server";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { placeFavorites, placeLikes, places, users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

export async function GET(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await ctx.params;
  const placeId = Number(id);
  const url = new URL(req.url);
  const withWorld = url.searchParams.get("world") === "1";
  const [row] = await db
    .select({
      id: places.id,
      name: places.name,
      description: places.description,
      thumbnail: places.thumbnail,
      visits: places.visits,
      ownerId: places.ownerId,
      ownerName: users.username,
      ownerAvatar: users.avatar,
      createdAt: places.createdAt,
      updatedAt: places.updatedAt,
      stats: sql<unknown>`${places.world}->'stats'`,
      world: withWorld ? places.world : sql<null>`null`,
      likes: sql<number>`(select count(*)::int from place_likes pl where pl.place_id = ${places.id})`,
      playing: sql<number>`(select count(*)::int from users u2 where u2.current_place_id = ${places.id} and u2.presence = 'ingame' and u2.last_seen > now() - interval '90 seconds')`,
    })
    .from(places)
    .innerJoin(users, eq(places.ownerId, users.id))
    .where(eq(places.id, placeId))
    .limit(1);
  if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const [[liked], [fav]] = await Promise.all([
    db
      .select()
      .from(placeLikes)
      .where(and(eq(placeLikes.userId, me.id), eq(placeLikes.placeId, placeId))),
    db
      .select()
      .from(placeFavorites)
      .where(and(eq(placeFavorites.userId, me.id), eq(placeFavorites.placeId, placeId))),
  ]);
  return NextResponse.json({ place: row, liked: !!liked, favorited: !!fav });
}
