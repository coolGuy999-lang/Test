import { NextResponse } from "next/server";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const status = body.status === "ingame" ? "ingame" : body.status === "offline" ? "offline" : "online";
  const placeId = status === "ingame" && Number(body.placeId) ? Number(body.placeId) : null;
  const today = new Date().toISOString().slice(0, 10);
  let claimed = false;
  const patch: Partial<typeof users.$inferInsert> = {
    presence: status,
    lastSeen: status === "offline" ? new Date(0) : new Date(),
    currentPlaceId: placeId,
  };
  if (status !== "offline" && me.lastRobuxClaim !== today) {
    patch.lastRobuxClaim = today;
    patch.robux = sql`${users.robux} + 100` as unknown as number;
    claimed = true;
  }
  const [row] = await db.update(users).set(patch).where(eq(users.id, me.id)).returning({ robux: users.robux });
  return NextResponse.json({ ok: true, robux: row?.robux ?? me.robux, claimed });
}
