import { NextResponse } from "next/server";
import { and, eq, or } from "drizzle-orm";
import { db } from "@/db";
import { follows, friendships, users } from "@/db/schema";
import { getCurrentUser, publicUser } from "@/lib/auth";

export async function GET() {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const rows = await db
    .select()
    .from(friendships)
    .where(or(eq(friendships.requesterId, me.id), eq(friendships.addresseeId, me.id)));
  const ids = new Set<number>();
  rows.forEach((r) => {
    ids.add(r.requesterId);
    ids.add(r.addresseeId);
  });
  ids.delete(me.id);
  const people = ids.size
    ? await db
        .select()
        .from(users)
        .where(or(...[...ids].map((id) => eq(users.id, id))))
    : [];
  const byId = new Map(people.map((p) => [p.id, publicUser(p)]));
  const friends = [];
  const incoming = [];
  const outgoing = [];
  for (const r of rows) {
    const otherId = r.requesterId === me.id ? r.addresseeId : r.requesterId;
    const u = byId.get(otherId);
    if (!u) continue;
    if (r.status === "accepted") friends.push(u);
    else if (r.addresseeId === me.id) incoming.push(u);
    else outgoing.push(u);
  }
  const order = { ingame: 0, online: 1, offline: 2 } as Record<string, number>;
  friends.sort((a, b) => order[a.presence] - order[b.presence] || a.username.localeCompare(b.username));
  return NextResponse.json({ friends, incoming, outgoing });
}

export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const action = body.action as string;
  const targetId = Number(body.userId);
  if (!targetId || targetId === me.id) return NextResponse.json({ error: "Bad target" }, { status: 400 });

  const pairWhere = or(
    and(eq(friendships.requesterId, me.id), eq(friendships.addresseeId, targetId)),
    and(eq(friendships.requesterId, targetId), eq(friendships.addresseeId, me.id)),
  );

  if (action === "add") {
    const [existing] = await db.select().from(friendships).where(pairWhere).limit(1);
    if (existing) {
      if (existing.status === "pending" && existing.addresseeId === me.id) {
        await db.update(friendships).set({ status: "accepted" }).where(eq(friendships.id, existing.id));
        return NextResponse.json({ ok: true, status: "friends" });
      }
      return NextResponse.json({ ok: true, status: existing.status === "accepted" ? "friends" : "outgoing" });
    }
    await db.insert(friendships).values({ requesterId: me.id, addresseeId: targetId, status: "pending" });
    return NextResponse.json({ ok: true, status: "outgoing" });
  }
  if (action === "accept") {
    await db
      .update(friendships)
      .set({ status: "accepted" })
      .where(and(eq(friendships.requesterId, targetId), eq(friendships.addresseeId, me.id)));
    return NextResponse.json({ ok: true, status: "friends" });
  }
  if (action === "remove") {
    await db.delete(friendships).where(pairWhere);
    return NextResponse.json({ ok: true, status: "none" });
  }
  if (action === "follow") {
    await db.insert(follows).values({ followerId: me.id, followingId: targetId }).onConflictDoNothing();
    return NextResponse.json({ ok: true, isFollowing: true });
  }
  if (action === "unfollow") {
    await db.delete(follows).where(and(eq(follows.followerId, me.id), eq(follows.followingId, targetId)));
    return NextResponse.json({ ok: true, isFollowing: false });
  }
  return NextResponse.json({ error: "Unknown action" }, { status: 400 });
}
