import { NextResponse } from "next/server";
import { and, eq, ilike, or, sql, desc } from "drizzle-orm";
import { db } from "@/db";
import { follows, friendships, places, users, type AvatarData } from "@/db/schema";
import { getCurrentUser, hashPassword, publicUser, verifyPassword } from "@/lib/auth";
import { cookies } from "next/headers";

export async function GET(req: Request) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const url = new URL(req.url);
  const q = url.searchParams.get("q");
  const id = url.searchParams.get("id");

  if (q !== null) {
    const term = q.trim();
    const rows = await db
      .select()
      .from(users)
      .where(term ? ilike(users.username, `%${term}%`) : sql`true`)
      .orderBy(desc(users.lastSeen))
      .limit(30);
    return NextResponse.json({ users: rows.map(publicUser) });
  }

  if (id) {
    const uid = Number(id);
    const [u] = await db.select().from(users).where(eq(users.id, uid)).limit(1);
    if (!u) return NextResponse.json({ error: "Not found" }, { status: 404 });
    const [[fr], [fo], [fg]] = await Promise.all([
      db
        .select({ c: sql<number>`count(*)::int` })
        .from(friendships)
        .where(
          and(eq(friendships.status, "accepted"), or(eq(friendships.requesterId, uid), eq(friendships.addresseeId, uid))),
        ),
      db.select({ c: sql<number>`count(*)::int` }).from(follows).where(eq(follows.followingId, uid)),
      db.select({ c: sql<number>`count(*)::int` }).from(follows).where(eq(follows.followerId, uid)),
    ]);
    const [rel] = await db
      .select()
      .from(friendships)
      .where(
        or(
          and(eq(friendships.requesterId, me.id), eq(friendships.addresseeId, uid)),
          and(eq(friendships.requesterId, uid), eq(friendships.addresseeId, me.id)),
        ),
      )
      .limit(1);
    const [followRow] = await db
      .select()
      .from(follows)
      .where(and(eq(follows.followerId, me.id), eq(follows.followingId, uid)))
      .limit(1);
    const creations = await db
      .select({
        id: places.id,
        name: places.name,
        thumbnail: places.thumbnail,
        visits: places.visits,
        createdAt: places.createdAt,
      })
      .from(places)
      .where(and(eq(places.ownerId, uid), eq(places.isPublic, true)))
      .orderBy(desc(places.createdAt));
    let friendStatus: "none" | "friends" | "outgoing" | "incoming" = "none";
    if (rel) {
      if (rel.status === "accepted") friendStatus = "friends";
      else friendStatus = rel.requesterId === me.id ? "outgoing" : "incoming";
    }
    return NextResponse.json({
      user: publicUser(u),
      counts: { friends: fr?.c ?? 0, followers: fo?.c ?? 0, following: fg?.c ?? 0 },
      friendStatus,
      isFollowing: !!followRow,
      creations,
    });
  }
  return NextResponse.json({ error: "Bad request" }, { status: 400 });
}

export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const action = body.action as string;

  if (action === "avatar") {
    const a = body.avatar as AvatarData;
    const hex = /^#[0-9a-fA-F]{6}$/;
    const keys: (keyof AvatarData)[] = ["head", "torso", "leftArm", "rightArm", "leftLeg", "rightLeg"];
    for (const k of keys) if (!hex.test(String(a[k]))) return NextResponse.json({ error: "Bad color" }, { status: 400 });
    const avatar: AvatarData = {
      head: a.head,
      torso: a.torso,
      leftArm: a.leftArm,
      rightArm: a.rightArm,
      leftLeg: a.leftLeg,
      rightLeg: a.rightLeg,
      shirt: a.shirt && hex.test(a.shirt) ? a.shirt : null,
      pants: a.pants && hex.test(a.pants) ? a.pants : null,
      hat: (["none", "cap", "tophat", "visor"] as const).includes(a.hat) ? a.hat : "none",
      face: (["smile", "happy", "serious"] as const).includes(a.face) ? a.face : "smile",
    };
    await db.update(users).set({ avatar }).where(eq(users.id, me.id));
    return NextResponse.json({ ok: true, avatar });
  }

  if (action === "description") {
    const description = String(body.description ?? "").slice(0, 1000);
    await db.update(users).set({ description }).where(eq(users.id, me.id));
    return NextResponse.json({ ok: true });
  }

  if (action === "language") {
    const language = body.language === "ru" ? "ru" : "en";
    await db.update(users).set({ language }).where(eq(users.id, me.id));
    const store = await cookies();
    store.set("rbx_lang", language, { path: "/", maxAge: 60 * 60 * 24 * 365 });
    return NextResponse.json({ ok: true });
  }

  if (action === "password") {
    const current = String(body.current ?? "");
    const next = String(body.next ?? "");
    if (!verifyPassword(current, me.passwordHash)) {
      return NextResponse.json({ error: "Current password is incorrect." }, { status: 400 });
    }
    if (next.length < 8) return NextResponse.json({ error: "Password must be at least 8 characters." }, { status: 400 });
    await db.update(users).set({ passwordHash: hashPassword(next) }).where(eq(users.id, me.id));
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: "Unknown action" }, { status: 400 });
}
